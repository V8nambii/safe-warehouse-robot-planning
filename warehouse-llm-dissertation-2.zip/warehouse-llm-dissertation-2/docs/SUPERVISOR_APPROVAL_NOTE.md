# Draft note to supervisor

**Subject:** Confirmation of dissertation project scope – LLM warehouse task and route planning

Dear Professor,

Thank you for sharing the Qwen robot simulator notebook. I have reviewed the approach and would like to develop it into the following dissertation project:

**LLM-Assisted Warehouse Robot Task and Route Planning in a Simulated Fulfilment Centre**

The main experiment would generate natural-language pick-and-deliver instructions. Qwen would return a structured action, requested item, destination and coordinate route. The simulator would verify that the plan identifies the correct pallet and dock, follows legal movements, visits a pickup-access cell and completes delivery.

The professor's direction task and a standalone route task would be retained as diagnostic baselines. A traditional A* planner would provide the optimal mission route, and the LLM response would be checked for collisions, illegal movements, pickup completion, goal completion and path efficiency. This would remain a software simulation; I would not attempt to build or control a physical robot.

My proposed research questions examine the effects of task difficulty and prompt design, the rate of valid LLM-generated routes, and route efficiency compared with A*. Qwen 7B would remain the primary model because it is used in the supplied notebook.

Could you please confirm:

1. whether the route-planning task is an appropriate extension;
2. whether evaluating Qwen 7B alone is sufficient or a second model is expected; and
3. whether the proposed experiment size—480 direction, 240 route and 240 pick-and-deliver trials—is suitable?

Kind regards,  
Naman Langa
