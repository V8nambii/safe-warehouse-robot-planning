# Project proposal

## Working title

**LLM-Assisted Warehouse Robot Task and Route Planning in a Simulated Fulfilment Centre**

## Plain-language description

The project creates a small virtual warehouse containing racks, pallets, workers, forklifts and docks. It automatically generates worker instructions such as “Collect Coffee from pallet P-5 and take it to Dock D-3.” A language model, initially Qwen 7B, must identify the correct task and produce a route. A Python simulator checks the item, destination, pickup location and every route step.

The route must start at the robot, visit a free cell beside the requested item, and finish at the requested dock. A traditional A* algorithm calculates the shortest valid mission route. The LLM route is checked for collisions, illegal movements, failure to pick the item, failure to reach the destination and unnecessary extra steps. The earlier spatial-direction task remains as a controlled baseline.

## Origin of the project

The supervisor supplied a Colab notebook titled **“Qwen robot simulator - original.ipynb.”** It contains a 10×10 warehouse, relative movement questions, a Python answer solver, an Ollama connection to Qwen 7B and CSV result logging. Its saved run reports 39 correct responses out of 100.

The supplied notebook is a useful proof of concept. This project develops it into a research system by correcting the state-transition logic, adding reproducible seeds, controlled difficulty, prompt conditions, route planning, richer metrics, automated tests, visualisation and statistical analysis.

## Problem statement

Warehouse navigation requires consistent spatial reasoning. LLMs can interpret natural-language instructions, but a fluent answer does not guarantee that the implied movement is geometrically correct or safe. A simulator makes this behaviour measurable because every generated task has deterministic ground truth.

## Aim

To develop and evaluate an LLM-assisted system that converts natural-language warehouse jobs into structured pick-and-deliver plans and safe routes in a simulated fulfilment centre.

## Objectives

1. Develop a deterministic 2D warehouse simulator with correct relative movement and orientation.
2. Generate direction, route and pick-and-deliver tasks at controlled difficulty levels.
3. Integrate Qwen through Ollama without training a new model.
4. Validate the LLM's chosen action, item, destination, pickup visit and route.
5. Compare LLM outputs with symbolic direction calculations and A* mission routes.
6. Measure accuracy, validity, safety, optimality, format compliance and latency.
7. Categorise model failures and identify conditions that produce them.
8. Deliver a reproducible experiment package and interactive demonstration.

## Research questions

**RQ1.** How accurately can an LLM identify the requested warehouse action, item and destination from natural-language instructions?

**RQ2.** How does prompt design affect task accuracy, route validity and output-format compliance?

**RQ3.** How often can an LLM produce a complete collision-free route that visits the item pickup area and reaches the correct destination?

**RQ4.** When an LLM mission is valid, how efficient is it compared with an optimal two-stage A* mission route?

**RQ5.** How does spatial difficulty affect the direction-reasoning baseline?

## Hypotheses

- **H1:** Task-and-route success will decrease as the required mission route becomes longer.
- **H2:** Explicit planning rules and an example will improve success compared with a minimal prompt.
- **H3:** Semantic task accuracy will be higher than full valid-mission accuracy because safe routing adds additional failure opportunities.
- **H4:** LLM-only routes will have a lower valid-route rate than the deterministic A* planner.
- **H5:** Direction accuracy will decrease as the number of movement and turning operations increases.

## Proposed contribution

The contribution is not a claim that a new robot or new LLM has been invented. The contribution is a controlled and reproducible evaluation framework that joins:

- natural-language warehouse tasks;
- structured pick-and-deliver action plans;
- a state-based spatial simulator;
- automatic ground-truth generation;
- a traditional path-planning baseline;
- systematic prompt and difficulty experiments; and
- explainable error categories.

## Scope

Included:

- One simulated robot
- A fixed 10×10 warehouse
- Eight relative directions for direction reasoning
- Four-direction movement for safe route planning
- Static obstacles
- Single-item pick-and-deliver jobs
- Qwen 7B as the primary evaluated model
- Offline, repeatable experiments

Excluded from the MSc scope:

- A physical robot or robotic arm
- Computer vision and object grasping
- Reinforcement learning
- Real Amazon warehouse data
- Multi-robot fleet optimisation
- Human-participant studies
- Claims of deployment safety

These exclusions keep the project achievable and make the evaluation easier to defend.

## Method summary

The simulator generates scenarios from fixed seeds. For a pick-and-deliver mission, it selects a blocked pallet, identifies its free access cells, selects a dock and calculates the shortest start-to-pickup-to-dock path. Qwen receives a worker instruction and returns a JSON action, item ID, destination ID and coordinate route. The evaluator verifies every semantic field and every movement. Separate direction and route tasks provide diagnostic baselines. Results are grouped by difficulty and prompt style with 95% Wilson confidence intervals.

## Ethical and safety position

The default project uses synthetic data, no personal information and no physical robot. It therefore presents low participant and operational risk. However, formal University ethics screening must still be checked. The report should clearly state that simulated performance does not establish real-world robot safety.
