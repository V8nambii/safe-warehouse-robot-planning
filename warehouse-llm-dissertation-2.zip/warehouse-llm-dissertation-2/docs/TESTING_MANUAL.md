# Complete testing manual

Testing is part of the research method. If the simulator is wrong, every model score is wrong.

## Testing levels

| Level | Question answered |
|---|---|
| Unit | Does one small function behave correctly? |
| Integration | Do simulator, prompt, parser and evaluator work together? |
| System | Can a user run the CLI/dashboard and obtain valid files? |
| Experimental | Is the final data collection controlled and reproducible? |

## 1. Automated unit and integration tests

Run:

```bash
python -m pytest -q
```

Expected result: all tests pass with no failures or errors.

### Direction and simulator tests

`test_relative_turns_are_correct`

- North + Right becomes East
- East + Left becomes North
- South + Back becomes North

`test_movement_respects_current_facing_direction`

- Forward from North changes y by -1
- Forward from East changes x by +1

This test protects against the orientation inconsistency in the starter notebook.

`test_turn_changes_facing_but_not_position`

- A turn changes orientation only

`test_qualitative_direction_uses_world_axes`

- Direction from origin to target is classified by coordinate signs

`test_direction_scenario_is_reproducible_and_self_consistent`

- Same seed gives identical scenario
- Replaying commands reaches the stored final pose
- Recalculated direction matches stored answer

`test_pick_and_deliver_mission_is_reproducible_and_valid`

- Same seed gives identical mission
- Optimal route begins at robot and ends at dock
- Route is legal and visits a pickup cell

### Planner tests

`test_astar_finds_shortest_path_around_obstacle`

- Uses a small known map
- Confirms route is valid
- Confirms exact shortest length

`test_validation_rejects_collision_and_teleport`

- A path through a rack fails collision checking
- A jump over a cell fails adjacency checking

### Parser and evaluator tests

`test_direction_parser_tracks_format_compliance`

- Exact answer is compliant
- Explanatory answer can be parsed but is not compliant
- Ambiguous answer is rejected

`test_route_parser_accepts_json_coordinates`

- Correct coordinate JSON is accepted
- prose and boolean coordinates are rejected

`test_mission_parser_requires_task_fields_and_route`

- Correct structured mission is parsed
- Empty object is rejected

`test_oracle_verifies_direction_pipeline`

- Full direction pipeline scores perfect ground truth

`test_oracle_verifies_route_pipeline`

- Full route pipeline validates optimal A* paths

`test_oracle_verifies_pick_and_deliver_pipeline`

- Full mission pipeline validates action, item, dock, pickup and path

`test_wilson_interval_is_bounded_and_contains_observed_rate`

- Statistical interval remains between zero and one
- Observed proportion lies inside it

## 2. Larger oracle integration check

Run three cases for every condition:

```bash
python -m warehouse_llm.cli all \
  --client oracle \
  --cases 3 \
  --output-dir results/oracle_check
```

This now runs:

- 4 difficulties × 4 direction styles × 3 = 48 direction cases
- 4 difficulties × 3 route styles × 3 = 36 route cases
- 4 difficulties × 3 mission styles × 3 = 36 mission cases
- total = 120 pipeline cases

Expected:

- every success rate is 100%;
- every direction answer is strict and correct;
- every route is valid and optimal; and
- every mission has correct task fields, pickup visit, destination and optimal route.

If any oracle condition is below 100%, do not run Qwen.

## 3. Manual ground-truth inspection

For at least five seeds per difficulty:

1. Generate the mission in the dashboard.
2. Record robot start, item, pickup cell and dock.
3. Follow the green A* path cell by cell.
4. Confirm no cell is blocked.
5. Confirm a pickup-access cell occurs before the dock.
6. Count the number of movements.
7. Compare with `optimal_steps`.

Recommended manual seeds:

```text
101, 202, 303, 404, 505
```

This is not a statistical sample. It is a human sanity check of implementation.

## 4. Parser robustness tests

Try these responses in a small Python session:

Valid:

```json
{"action":"pick_and_deliver","item_id":"P-5","destination_id":"D-3","route":[[0,0],[1,0]]}
```

Parseable but format-noncompliant:

```text
Here is the plan: {"action":"pick_and_deliver","item_id":"P-5","destination_id":"D-3","route":[[0,0],[1,0]]}
```

Semantically wrong:

```json
{"action":"pick_and_deliver","item_id":"P-4","destination_id":"D-3","route":[[0,0],[1,0]]}
```

Invalid route shapes:

```json
{"action":"pick_and_deliver","item_id":"P-5","destination_id":"D-3","route":[]}
```

```json
{"action":"pick_and_deliver","item_id":"P-5","destination_id":"D-3","route":[[0,0],[2,0]]}
```

The first has no route. The second teleports two cells.

## 5. Command-line system test

Run a random baseline without Ollama:

```bash
python -m warehouse_llm.cli all --client random --cases 1 --output-dir results/random_check
```

Check that these files appear:

- direction CSV and summary JSON
- route CSV and summary JSON
- mission CSV and summary JSON

The random baseline is expected to fail many cases. The purpose is verifying file creation and failure recording.

## 6. Dashboard system test

Run:

```bash
streamlit run streamlit_app.py
```

Without Ollama:

- generate all three task types;
- change difficulty and seed;
- confirm the figures update;
- inspect prompts and optimal answers.

With Ollama:

- ask Qwen one direction question;
- ask Qwen one route question;
- ask Qwen one mission question;
- verify raw output and individual checks display;
- confirm the orange LLM route overlay appears when parseable.

## 7. Qwen pilot acceptance test

```bash
python -m warehouse_llm.cli direction --client ollama --model qwen:7b --cases 1 --seed 202600 --output-dir results/pilot
python -m warehouse_llm.cli route --client ollama --model qwen:7b --cases 1 --seed 202700 --output-dir results/pilot
python -m warehouse_llm.cli mission --client ollama --model qwen:7b --cases 1 --seed 202800 --output-dir results/pilot
```

Inspect every pilot row. The pilot passes when:

- no request/server error is stored as a normal answer;
- raw responses are preserved;
- identifiers and coordinates match the displayed prompt;
- booleans reflect the raw response;
- latency is recorded;
- summary counts equal expected cases; and
- repeated seed generation produces the same scenario.

Do not require high model accuracy for pilot acceptance. The pilot checks measurement correctness, not the hypothesis.

## 8. Final experiment integrity tests

Before starting:

- freeze code and prompt text;
- record model digest/version;
- record Python/Ollama/runtime versions;
- confirm seeds and sample sizes;
- save test and oracle output; and
- obtain supervisor approval.

After completion:

- number of direction rows should be 480;
- number of route rows should be 240;
- number of mission rows should be 240;
- no duplicate scenario IDs should exist;
- every condition should have the approved sample count;
- every raw response should be present;
- all metrics should be reproducible from raw response and scenario seed.

## 9. Failure debugging order

If a test fails, check in this order:

1. Coordinate convention: top-left origin, y increases downward
2. Current facing versus world direction
3. Obstacle classification
4. Pickup-access cell calculation
5. A* route concatenation
6. JSON parsing
7. Task ID comparison
8. Route validation
9. Experiment grouping and seed
10. Result aggregation

Fix the first incorrect layer before examining later metrics.

## 10. Final acceptance criteria

The software is dissertation-ready only when:

- all automated tests pass;
- the 120-case oracle integration check is 100%;
- manual route checks agree with the software;
- the Qwen pilot produces valid data files;
- the final protocol is supervisor-approved;
- results can be regenerated from recorded seeds and software version; and
- no secrets, invented results or manually changed outputs are included.

