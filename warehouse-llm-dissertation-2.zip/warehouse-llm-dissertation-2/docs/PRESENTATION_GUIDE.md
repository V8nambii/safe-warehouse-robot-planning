# Presentation and demonstration guide

## Suggested 10-slide structure

### Slide 1 — Title

- Project title
- Your name and programme
- Supervisor
- One-sentence purpose: testing whether an LLM can convert worker instructions into correct warehouse tasks and safe routes

### Slide 2 — Problem

- Warehouse pick-and-deliver instructions combine language, item identity, destination, position and movement
- A confident LLM answer may be spatially wrong
- A simulator provides known ground truth

### Slide 3 — Starting notebook

- Show the professor's 10×10 warehouse concept
- Explain that it generated direction questions for Qwen 7B
- Mention the saved 39/100 result only as motivation, not as your final result
- Explain the limitations you addressed: state consistency, reproducibility, difficulty and limited metrics

### Slide 4 — Your system

Show this flow:

```text
Mission generator → Prompt → Qwen task/route → Parser → Automatic evaluator
        │                                            ↑
        ├── Symbolic direction ground truth ─────────┤
        └── A* optimal route ground truth ───────────┘
```

### Slide 5 — Research questions

Present RQ1–RQ5 briefly. Do not crowd the slide with hypotheses.

### Slide 6 — Experimental design

- Four difficulty levels
- Prompt conditions
- Fixed seeds
- Direction and route sample sizes
- Temperature and model version
- Main metrics

### Slide 7 — Live demonstration

In the Streamlit dashboard:

1. Generate a medium pick-and-deliver mission.
2. Point out robot start, requested pallet, pickup-access cell, dock and obstacles.
3. Show the worker instruction and optimal two-stage A* route.
4. Ask Qwen and inspect its action, item ID, destination ID and route.
5. Show which semantic and safety checks pass or fail.
6. Briefly switch to the direction baseline if time permits.

Keep a recorded backup demonstration in case the model server is slow. The recording should use genuine outputs.

### Slide 8 — Results

- One valid-mission figure
- One task-accuracy versus route-validity comparison
- Numerators/denominators and confidence intervals
- Two or three main findings only

### Slide 9 — Error analysis and limitations

- One representative direction error
- One collision or invalid-route example
- Synthetic map, one primary model, static obstacles, no physical robot
- Why A* remains the safety/geometry checker

### Slide 10 — Conclusion

- Direct answer to the research question
- Technical contribution
- Practical meaning
- One or two future-work ideas

## Two-minute project explanation

> This project evaluates whether a language model can convert a warehouse worker's instruction into a correct pick-and-deliver plan. The model must select the requested action, pallet and dock and produce a complete coordinate route. A Python simulator independently knows the valid pickup cells, and a two-stage A* planner calculates the optimal start-to-pickup-to-dock route. Every model route is checked for illegal movement, collision, pickup completion, destination completion and efficiency. I vary task difficulty and prompt design, with the professor's spatial-direction task retained as a baseline. The purpose is not to replace a robot's safety planner with an LLM, but to show how language understanding can be combined with deterministic verification.

## Questions you should be ready to answer

**Why use an LLM if A* already solves routes?**  
The LLM is useful for interpreting flexible natural-language goals. A* provides reliable geometric execution and ground truth. The study measures whether the LLM can contribute safely, not whether it should replace A*.

**What is original?**  
The controlled extension of the starter simulator: corrected state transitions, natural-language mission generation, structured task validation, two-stage pickup/delivery planning, difficulty manipulation, prompt comparison, multiple metrics, failure taxonomy, statistical analysis and reproducible software.

**Why Qwen 7B?**  
It was used in the supervisor's starter notebook and is small enough for local/Colab evaluation. The report should also acknowledge that results may not generalise to other models.

**How do you know the ground truth is correct?**  
State transitions and A* are deterministic, scenario generation is reproducible, and automated unit tests verify rotations, movements, parsing, routes and evaluator behaviour.

**Why four-direction routes but eight direction labels?**  
Four-direction motion gives unambiguous legal warehouse steps and simple collision checking. Eight qualitative labels allow diagonal relative location without requiring diagonal physical movement.

**Can this control a real robot?**  
No. It is a research simulator. Real deployment would require perception, localisation, hardware controls, dynamic safety systems and extensive validation.
