# Experiment protocol

Follow this protocol consistently. Any change made after viewing final results must be reported.

## 1. Variables

### Independent variables

- Task: direction reasoning, standalone route planning or pick-and-deliver mission
- Difficulty: easy, medium, hard or expert
- Prompt style:
  - Direction: minimal, rules, few-shot or distractor-map
  - Route: minimal, rules or few-shot
  - Mission: minimal, rules or few-shot
- Model: Qwen 7B initially; add a second model only with supervisor approval

### Direction outcomes

- **Accuracy:** parsed direction equals symbolic ground truth
- **Strict accuracy:** answer is correct and contains exactly the required direction
- **Format compliance:** response follows the one-label contract
- **Latency:** model response time in milliseconds

### Route outcomes

- Parseable JSON path
- Correct start coordinate
- Goal reached
- Adjacent legal movements
- Collision-free path
- Valid-route rate
- Optimal-route rate
- Path efficiency: optimal A* steps divided by LLM route steps
- Latency

### Pick-and-deliver mission outcomes

- JSON/schema compliance
- Correct `pick_and_deliver` action
- Correct item ID
- Correct destination dock ID
- Semantic task accuracy: action, item and destination all correct
- Parseable coordinate route
- Correct starting coordinate
- Collision-free adjacent movements
- Pickup-access cell visited
- Correct destination reached
- Valid-mission rate: semantic task and complete route are both correct
- Optimal-mission rate and path efficiency against two-stage A*
- Latency

## 2. Difficulty definition

| Difficulty | Direction instructions | Maximum movement | Minimum requested A* route |
|---|---:|---:|---:|
| Easy | 1 | 1 cell | 3 steps |
| Medium | 3 | 2 cells | 6 steps |
| Hard | 5 | 3 cells | 9 steps |
| Expert | 7 | 3 cells | 12 steps |

Turning probability also rises with difficulty. The route generator uses the requested minimum when a connected pair is available and records the actual optimal length.

## 3. Required software checks

Run:

```bash
python -m pytest -q
python -m warehouse_llm.cli all --client oracle --cases 2 --output-dir results/oracle_check
```

All automated tests must pass. The oracle must score 100%. If it does not, stop and fix the pipeline. Never include oracle results as model performance.

## 4. Pilot

Run one case per condition:

```bash
python -m warehouse_llm.cli direction --client ollama --model qwen:7b --cases 1 --seed 202600 --output-dir results/pilot
python -m warehouse_llm.cli route --client ollama --model qwen:7b --cases 1 --seed 202700 --output-dir results/pilot
python -m warehouse_llm.cli mission --client ollama --model qwen:7b --cases 1 --seed 202800 --output-dir results/pilot
```

Manually inspect every pilot row for:

- readable question wording;
- agreement between displayed scenario and ground truth;
- correct result parsing;
- no model/server errors hidden as answers; and
- reasonable execution time.

You may fix software after the pilot. Delete the pilot from the final statistical analysis and document material fixes.

## 5. Proposed final sample

### Direction experiment

4 difficulties × 4 prompt styles × 30 cases = **480 trials per model**.

### Route experiment

4 difficulties × 3 prompt styles × 20 cases = **240 trials per model**.

### Pick-and-deliver mission experiment

4 difficulties × 3 prompt styles × 20 cases = **240 trials per model**.

Total = **960 trials per model**.

This is a defensible proposed design, not a substitute for supervisor approval or a formal power analysis. If runtime is excessive, agree a reduced design before running the final experiment; do not reduce it after seeing unfavourable results.

## 6. Controls

Keep the following fixed:

- Model name and exact model digest/version
- Temperature: 0
- Ollama seed: 42
- Scenario seeds: 202600 for direction, 202700 for routes and 202800 for missions
- Simulator version
- Prompt text
- Hardware/runtime type
- Output parser

Record:

- Date and time of each run
- Colab runtime/GPU or local machine specification
- Python version
- Ollama version
- Model details shown by Ollama
- Git commit or frozen source ZIP checksum

## 7. Final run

```bash
python -m warehouse_llm.cli direction --client ollama --model qwen:7b --cases 30 --seed 202600 --output-dir results/final
python -m warehouse_llm.cli route --client ollama --model qwen:7b --cases 20 --seed 202700 --output-dir results/final
python -m warehouse_llm.cli mission --client ollama --model qwen:7b --cases 20 --seed 202800 --output-dir results/final
```

Do not selectively rerun individual failures. If the run stops, keep the existing CSV, identify the cause and restart the complete affected condition with documented seeds.

## 8. Analysis

```bash
python analyse_results.py --input-dir results/final --output-dir results/analysis
```

Report the numerator and denominator alongside percentages. Use 95% Wilson confidence intervals for binary success rates. Discuss effect sizes and patterns; do not claim statistical or practical significance from a visual difference alone.

Recommended analyses:

1. Accuracy/valid-route rate by difficulty
2. Accuracy/valid-route rate by prompt style
3. Strict accuracy versus lenient parsed accuracy
4. Direction confusion matrix
5. Route failure categories
6. Path efficiency for valid routes
7. Latency distribution
8. Semantic task accuracy versus complete valid-mission rate
9. Mission failures caused by item, destination, pickup or navigation errors

For inferential modelling, a binary logistic regression with difficulty and prompt style is appropriate, subject to supervisor/statistics guidance.

## 9. Failure taxonomy

Direction errors:

- Incorrect coordinate update
- Incorrect handling of current facing
- Incorrect turn
- Incorrect final target direction
- Correct semantic answer but broken output format
- Ambiguous/unparseable response

Route errors:

- Invalid JSON
- Wrong starting cell
- Teleport/non-adjacent movement
- Collision with obstacle
- Leaves the grid
- Does not reach goal
- Reaches goal but is longer than A*

Mission errors:

- Wrong or missing action
- Wrong pallet/item ID
- Wrong destination dock
- Correct task fields but invalid route
- Route never visits a free cell beside the pallet
- Pickup visited but requested destination not reached
- Valid mission but longer than the optimal two-stage A* mission

Keep representative examples of each failure for the discussion chapter.
