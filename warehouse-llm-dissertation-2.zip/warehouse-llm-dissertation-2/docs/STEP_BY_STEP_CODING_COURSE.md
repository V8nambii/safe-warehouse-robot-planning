# Complete step-by-step coding course

This guide teaches the project from the smallest idea to the completed experiment. Read the named source file while following each lesson. Do not try to memorise the whole package at once.

## Lesson 0 — Understand exactly what the project does

### Input

A warehouse worker gives a natural-language instruction:

> Collect Coffee from pallet P-5, then take it to Dock D-3.

### LLM output

The model must return structured JSON:

```json
{
  "action": "pick_and_deliver",
  "item_id": "P-5",
  "destination_id": "D-3",
  "route": [[0, 2], [1, 2], [2, 2], [2, 1], [3, 1], [4, 1], [4, 0]]
}
```

### Automatic checks

Python asks:

1. Is the JSON readable?
2. Is the action `pick_and_deliver`?
3. Did the model select P-5?
4. Did it select D-3?
5. Does the route begin at the robot?
6. Does every movement change one coordinate by exactly one?
7. Does the route avoid racks, pallets, workers, forklifts and columns?
8. Does it visit a free cell beside P-5?
9. Does it finish at D-3?
10. How many extra steps did it use compared with A*?

This is why the project is **LLM-assisted**. The LLM understands and proposes. Deterministic code verifies and provides the safety/geometry baseline.

## Essential vocabulary

| Term | Simple meaning |
|---|---|
| LLM | Language model that reads an instruction and writes a plan |
| Simulator | Virtual warehouse whose state is controlled by Python |
| State | Current information, such as robot position and facing |
| Coordinate | Grid location written as `(x,y)` |
| Pose | Position plus facing direction |
| Obstacle | Cell the robot cannot enter |
| Pallet | Blocked object containing the item to collect |
| Pickup-access cell | Free cell directly beside the pallet |
| Dock | Traversable delivery destination |
| Route | Ordered list of coordinates |
| A* | Search algorithm that finds a shortest path |
| Ground truth | Correct answer calculated independently of the LLM |
| Prompt | Text sent to the LLM |
| Parser | Code that converts the model's text into Python data |
| Metric | Numeric measurement such as success rate or route length |
| Seed | Number that makes random scenario generation reproducible |

## Complete data flow

```text
Fixed seed
   ↓
Mission generator ──→ worker instruction
   │                        ↓
   │                  prompt builder
   │                        ↓
   │                      Qwen
   │                        ↓
   │                  JSON parser
   │                        ↓
   ├─ expected item/dock ─→ semantic checks
   ├─ pickup cells ───────→ pickup check
   └─ optimal A* path ────→ safety and efficiency checks
                            ↓
                         CSV row
```

## Lesson 1 — Install and inspect the package

Files used: `pyproject.toml`, `requirements.txt`, `README.md`

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
python -m pytest -q
```

`pyproject.toml` defines:

- package name and version;
- Python version;
- required libraries;
- command-line entry point; and
- test settings.

The `-e` installation is editable: changing source code immediately changes the installed project. `[dev]` installs the testing dependency.

Checkpoint: explain why a virtual environment prevents dependency conflicts.

## Lesson 2 — Represent positions and directions

File: `warehouse_llm/domain.py`

### `Point`

```python
@dataclass(frozen=True, order=True)
class Point:
    x: int
    y: int
```

A point contains two integers. `frozen=True` makes it immutable, so it can safely be used as a dictionary key or set member. `order=True` allows stable sorting.

`Point.moved(dx, dy, steps)` returns a new point rather than changing the original point.

### `Direction`

Eight fixed world directions are stored in clockwise order:

```text
North → North-East → East → South-East →
South → South-West → West → North-West
```

`DIRECTION_VECTORS` converts a direction into coordinate change. Because the screen origin is top-left:

- North is `(0,-1)`
- East is `(1,0)`
- South is `(0,1)`
- West is `(-1,0)`

### Relative direction

“Forward” depends on the robot's facing. If it faces East, Forward means world East. If it faces South, Left means world East.

`turn_direction(facing, relative)` converts a relative direction to a world direction by adding a clockwise offset modulo eight.

### Scenario dataclasses

- `DirectionScenario`: movement/facing question
- `RouteScenario`: start, goal and optimal path
- `MissionScenario`: start, pallet, dock, pickup cells, worker instruction and optimal mission path

Checkpoint: calculate world movement for a robot facing South-West and told to move Right.

## Lesson 3 — Build the warehouse map

File: `warehouse_llm/warehouse.py`

`WarehouseMap` stores:

- width and height;
- a dictionary from `Point` to object label; and
- labels that are traversable.

The original professor map is transcribed in `default_warehouse()`.

Important methods:

| Method | Purpose |
|---|---|
| `in_bounds` | Reject coordinates outside 0–9 |
| `is_blocked` | Treat racks, pallets, people, forklifts and columns as obstacles |
| `is_free` | Require in-bounds and not blocked |
| `free_points` | List possible robot cells |
| `neighbors4` | Legal North/East/South/West neighbours |
| `pallet_objects` | List pickable pallet targets |
| `dock_objects` | List delivery destinations |
| `access_points` | Free orthogonal cells beside a blocked item |

Docks are traversable because the robot must finish on them. Pallets remain blocked because a robot approaches a pallet rather than driving through it.

Checkpoint: explain why “pick the pallet” means visiting an adjacent free cell rather than entering the pallet coordinate.

## Lesson 4 — Simulate relative movement correctly

File: `warehouse_llm/simulator.py`

`apply_command` handles two cases:

1. A turn changes facing but not position.
2. A movement converts the relative direction to a world vector and checks each travelled cell.

Checking every intermediate cell matters. A three-cell move cannot jump over an obstacle simply because the final cell is free.

`possible_moves` generates only movements that remain inside the grid and avoid obstacles.

`generate_direction_scenario`:

1. creates its own `random.Random(seed)` object;
2. selects a free start and facing direction;
3. generates legal movement/turn commands;
4. selects a warehouse target;
5. calculates the final pose; and
6. calculates the target's qualitative direction.

The same seed and difficulty always produce the same scenario.

Checkpoint: run the same seed twice and compare the complete dataclass.

## Lesson 5 — Understand A* route planning

File: `warehouse_llm/planner.py`

A* keeps a priority queue of cells. Its priority is:

```text
cost already travelled + estimated cost to goal
```

The estimate is Manhattan distance:

```text
|x1 - x2| + |y1 - y2|
```

This estimate is appropriate because routes move only North, East, South or West.

Main structures:

- `frontier`: cells waiting to be explored;
- `best_cost`: cheapest known cost to each cell; and
- `came_from`: parent pointers used to reconstruct the route.

A* returns a list including both start and goal. If no route exists, it returns `None`.

`validate_path` does not trust any route. It checks:

- non-empty and parseable;
- correct start;
- correct goal;
- adjacent steps; and
- collision-free cells.

Checkpoint: draw a 5×5 grid with a vertical wall and manually show why A* must go around it.

## Lesson 6 — Generate a complete pick-and-deliver mission

File: `warehouse_llm/simulator.py`, method `generate_mission_scenario`

The generator performs these exact steps:

1. Validate the difficulty name.
2. Initialise a private seeded random generator.
3. Choose one pallet.
4. Choose one dock.
5. Choose a free robot start.
6. Find every free orthogonal cell beside the pallet.
7. For each possible pickup cell:
   - run A* from start to pickup;
   - run A* from pickup to dock;
   - join the routes without duplicating the pickup cell.
8. Select the combined route with the fewest steps.
9. Ensure its length suits the difficulty when possible.
10. Generate the natural-language worker instruction.
11. Store all facts in a `MissionScenario`.

The optimal mission is therefore not simply `start → dock`. It is:

```text
start → accessible cell beside requested pallet → requested dock
```

Different difficulty levels use different instruction wording and minimum route lengths. Easy names the pallet and dock directly. Expert includes distracting language and emphasises which dock not to use.

Checkpoint: explain why all possible pickup cells are considered rather than choosing the first adjacent cell.

## Lesson 7 — Build controlled prompts

File: `warehouse_llm/prompts.py`

The mission output contract is:

```json
{
  "action": "pick_and_deliver",
  "item_id": "P-x",
  "destination_id": "D-x",
  "route": [[x, y], [x, y]]
}
```

Every prompt contains the same scenario facts. Prompt style changes the assistance:

- `minimal`: facts and output schema only;
- `rules`: explicit movement, collision, pickup and destination rules;
- `few_shot`: rules plus one solved example.

This separation makes prompt style an experimental independent variable.

The model sees blocked coordinates because it cannot plan a route without the map. It sees the requested item and destination, but it must correctly copy their identifiers into the structured task plan.

Checkpoint: state which prompt information must stay identical across conditions and which part deliberately changes.

## Lesson 8 — Connect to Qwen through Ollama

File: `warehouse_llm/llm.py`

`OllamaClient.generate`:

1. builds an HTTP JSON request;
2. sends the model name, user prompt, temperature and seed;
3. waits for a non-streaming response;
4. extracts `message.content`; and
5. records latency.

Temperature is zero to reduce randomness. The scenario seed and Ollama seed are different concepts:

- scenario seed controls which warehouse problem is generated;
- model seed controls generation behaviour.

`OracleClient` never calls an LLM. It returns ground truth and is used only to prove that the experiment pipeline can score a perfect answer.

`RandomBaselineClient` provides a weak baseline and is clearly labelled as non-LLM.

Checkpoint: explain why oracle accuracy must not appear as an experimental model result.

## Lesson 9 — Parse untrusted model output

File: `warehouse_llm/parsing.py`

LLM text is treated as untrusted data.

`parse_mission_plan`:

1. tries to parse the complete response as JSON;
2. if needed, extracts the first `{...}` object;
3. requires a dictionary;
4. requires string action/item/destination fields;
5. parses the route as a list of integer coordinate pairs;
6. rejects booleans pretending to be integers;
7. rejects empty or excessively large routes; and
8. records whether the exact output contract was followed.

Parsing and correctness are separate. A response can be valid JSON but select the wrong item.

Checkpoint: give one example of parseable-but-wrong output and one example of correct meaning with broken formatting.

## Lesson 10 — Validate the complete mission

Files: `warehouse_llm/planner.py`, `warehouse_llm/evaluator.py`

`validate_mission` first runs ordinary route validation. It then checks whether any route point before the final dock is one of the permitted pickup-access cells.

The evaluator separately calculates:

- `action_correct`;
- `item_correct`;
- `destination_correct`;
- `task_correct`;
- `parseable_route`;
- `starts_correctly`;
- `reaches_destination`;
- `moves_are_adjacent`;
- `collision_free`;
- `pickup_visited`;
- `valid_mission`;
- `optimal_mission`; and
- `path_efficiency`.

`valid_mission` is intentionally strict:

```text
correct action AND correct item AND correct destination
AND valid route AND pickup visited
```

Path efficiency is:

```text
optimal A* mission steps / LLM mission steps
```

A valid optimal route scores 1.0. A longer route scores below 1.0. Invalid missions score 0.

Checkpoint: explain why `task_correct` and `valid_mission` should both be reported.

## Lesson 11 — Run controlled experiments

Files: `warehouse_llm/evaluator.py`, `warehouse_llm/cli.py`

Example:

```bash
python -m warehouse_llm.cli mission \
  --client ollama \
  --model qwen:7b \
  --cases 20 \
  --seed 202800 \
  --output-dir results/final
```

The loop order is:

```text
difficulty → prompt style → case number
```

Each case gets a unique seed derived from the base seed. Every response becomes one CSV row. JSON summaries aggregate the conditions.

Do not delete failures or repeat only selected cases. That would bias the experiment.

Checkpoint: calculate how `4 difficulties × 3 styles × 20 cases` becomes 240 mission trials.

## Lesson 12 — Use the interactive dashboard

File: `streamlit_app.py`

```bash
streamlit run streamlit_app.py
```

The user selects task, difficulty, seed and prompt style. For a mission, the page displays:

- warehouse grid;
- robot start;
- requested pallet;
- optimal pickup-access cell;
- requested dock;
- A* route;
- complete prompt;
- Qwen raw response;
- individual validation results; and
- LLM route overlay.

The dashboard is for understanding and demonstration. The command-line experiment runner is used for final repeatable data collection.

Checkpoint: explain why clicking the dashboard repeatedly is not a controlled final experiment.

## Lesson 13 — Analyse the results

File: `analyse_results.py`

```bash
python analyse_results.py --input-dir results/final --output-dir results/analysis
```

The script:

- combines task CSV files;
- groups results by model, difficulty and prompt style;
- counts successes and sample sizes;
- calculates 95% Wilson confidence intervals;
- creates accuracy/success figures;
- produces direction confusion data;
- produces route and mission failure counts; and
- writes a Markdown summary.

Wilson intervals are used because success metrics are binary proportions and ordinary symmetric intervals behave badly near 0% or 100%.

Checkpoint: explain why “18/20, 90%” is more informative with a confidence interval than “90%” alone.

## Lesson 14 — Understand every source file

| File | One-sentence responsibility |
|---|---|
| `domain.py` | Immutable research data structures and direction mathematics |
| `warehouse.py` | Map, obstacles, pallets, docks and access cells |
| `simulator.py` | Reproducible direction, route and mission generation |
| `planner.py` | A* ground truth and route/mission validation |
| `prompts.py` | Controlled instructions and output contracts |
| `llm.py` | Qwen connection and non-LLM verification baselines |
| `parsing.py` | Safe conversion of model text into labels, routes and plans |
| `evaluator.py` | Trial loops, metrics, CSV and summary generation |
| `cli.py` | Reproducible command-line interface |
| `visualization.py` | Warehouse figures and route overlays |
| `streamlit_app.py` | Interactive demonstration |
| `analyse_results.py` | Confidence intervals, tables and figures |
| `tests/` | Proof that individual and combined behaviours are correct |

## Lesson 15 — Recommended study order

Day 1: coordinates, `Point`, directions and map  
Day 2: movement simulation and scenario seeds  
Day 3: A* on paper and in code  
Day 4: pick-and-deliver mission generation  
Day 5: prompts, JSON and Ollama  
Day 6: parsing, validation and metrics  
Day 7: tests and debugging  
Day 8: pilot experiment  
Day 9: result analysis and graphs  
Day 10: presentation practice and dissertation methodology

Do not move to the final experiment until you can explain Lessons 0–11 without reading every sentence.

