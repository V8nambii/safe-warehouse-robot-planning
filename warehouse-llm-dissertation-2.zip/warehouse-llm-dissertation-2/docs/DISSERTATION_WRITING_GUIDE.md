# Dissertation writing guide

Use your module handbook for the official word limit, required headings, referencing style and formatting. The percentages below are planning suggestions, not University rules.

## Suggested report structure

### Front matter

- Title page with your name, student ID, programme, supervisor and date
- Academic-integrity/AI-use declaration required by the University
- Abstract of approximately 200–300 words
- Acknowledgements if appropriate
- Table of contents
- List of figures and tables

### 1. Introduction — approximately 10–15%

Explain:

- why reliable task understanding and spatial reasoning matter for warehouse robots;
- why an LLM's fluent response may still be geometrically invalid;
- why a simulator provides objective ground truth;
- the research gap your controlled framework addresses;
- aim, objectives, research questions and hypotheses;
- project contributions; and
- report structure.

Do not begin with a long general history of AI. Move quickly from warehouse navigation to the exact research problem.

### 2. Literature review — approximately 20–25%

Organise by themes:

1. Task planning and spatial reasoning in language models
2. Embodied and robot navigation using language
3. Classical route and pickup/delivery planning, especially A*
4. Warehouse robot simulation and digital twins
5. LLM evaluation and benchmark design
6. Prompting, constrained outputs and failure analysis

For each theme, compare methods, datasets, assumptions and limitations. Finish by identifying what existing work does not answer and how your experiment addresses it. Use peer-reviewed and primary technical sources wherever possible.

### 3. Requirements and system design — approximately 10–15%

Include:

- functional and non-functional requirements;
- project scope and exclusions;
- architecture diagram;
- warehouse coordinate system;
- robot pose and command representation;
- pallet, dock and pickup-access representation;
- structured pick-and-deliver task schema;
- direction-ground-truth logic;
- two-stage A* mission planner and obstacle representation;
- LLM interface and response contracts;
- result schema; and
- design decisions and alternatives rejected.

Clearly explain why the LLM handles language reasoning while a deterministic simulator checks safety and geometry.

### 4. Methodology — approximately 15–20%

Describe the experiment precisely enough to reproduce it:

- research design;
- independent, dependent and controlled variables;
- four difficulty levels;
- prompt conditions;
- worker-instruction generation;
- semantic task and full-mission success definitions;
- scenario generation and fixed seeds;
- Qwen/Ollama configuration;
- pilot and final sample sizes;
- metrics and formulas;
- Wilson confidence intervals and any inferential analysis;
- error taxonomy;
- hardware and software;
- ethics and data management; and
- threats to validity.

Do not use the model to judge its own correctness. State that Python and A* supply ground truth.

### 5. Implementation — approximately 10–15%

Explain important engineering work rather than pasting entire files:

- correction of relative movement and orientation;
- pick-and-deliver mission generation;
- item/destination and pickup-access validation;
- deterministic generation;
- separation of simulator, prompt builder, model client and evaluator;
- route parsing and validation;
- CSV logging;
- dashboard;
- automated tests; and
- problems encountered and fixes.

Use short code excerpts only when they clarify a design decision. Put full code in the submitted archive or appendix.

### 6. Results — approximately 10–15%

Present factual results without explaining them too early:

- total trials and exclusions, if any;
- accuracy with numerator, denominator and 95% CI;
- semantic task accuracy and valid-mission rate;
- strict accuracy and format compliance;
- performance by difficulty and prompt style;
- pickup-visit, valid-route and optimal-mission rates;
- path efficiency;
- latency; and
- failure counts/confusion matrix.

Every table and figure needs a number, descriptive caption and reference in the text. Never write a result that is not present in the raw CSV.

### 7. Discussion — approximately 15–20%

Interpret the findings:

- answer each research question;
- assess each hypothesis;
- explain why particular tasks or prompts were difficult;
- compare findings with literature;
- analyse representative failures;
- discuss whether LLM-only route generation is suitable for safety-critical control;
- distinguish language-level task errors from geometry-level route errors;
- explain how a hybrid LLM plus deterministic planner could be safer;
- discuss generalisability beyond the 10×10 map; and
- separate evidence from speculation.

### 8. Evaluation and limitations — approximately 5–10%

Cover:

- internal validity: simulator correctness, parser effects and model nondeterminism;
- external validity: one map, synthetic tasks and one primary model;
- construct validity: compass-direction classification versus full spatial understanding;
- statistical limitations: sample size and multiple comparisons;
- engineering limitations: static obstacles and no physical embodiment; and
- reproducibility limitations: model tags and runtime differences.

### 9. Conclusion and future work — approximately 5%

Give a short answer to the main research problem, restate the actual contribution and identify realistic next steps such as dynamic obstacles, multi-robot coordination, vision-language input or a hybrid planner. Do not introduce new results.

### References and appendices

Appendices may contain:

- complete prompt templates;
- extended tables;
- selected failure examples;
- test output;
- environment details;
- ethics documentation; and
- a link or identifier for the source-code archive.

Do not move essential reasoning into appendices simply to avoid the word limit.

## Evidence to save while working

- Original professor notebook link and a downloaded copy
- Every version of the proposal approved by the supervisor
- Git history or dated source snapshots
- Pilot CSV files
- Final unedited CSV files
- Model/version output
- Runtime/hardware information
- Test output
- Generated figures
- Executed final notebook
- Meeting notes explaining scope decisions

## Writing rules that prevent common problems

- Use “the model produced” instead of implying the robot physically acted.
- Use “accuracy in this simulator” instead of claiming general intelligence.
- Separate A* ground truth from LLM output.
- State that the professor notebook was the starting point.
- Cite borrowed ideas and disclose assistance according to current University policy.
- Check every number against the saved CSV immediately before submission.
