# Results data dictionary

## Fields shared across tasks

| Field | Meaning |
|---|---|
| `scenario_id` | Unique task identifier |
| `seed` | Reproducible scenario seed |
| `task` | `direction` or `route` |
| `difficulty` | Easy, medium, hard or expert |
| `prompt_style` | Prompt condition |
| `model` | Model/client label |
| `raw_response` | Unedited model output |
| `latency_ms` | Model response time |
| `prompt_characters` | Prompt length in characters |

## Direction fields

| Field | Meaning |
|---|---|
| `instruction_count` | Number of movement/turn instructions |
| `start` | Initial coordinate |
| `start_facing` | Initial orientation |
| `final` | Simulator-calculated final coordinate |
| `final_facing` | Simulator-calculated final orientation |
| `target` | Target coordinate |
| `target_label` | Target warehouse object |
| `expected` | Symbolic ground-truth direction |
| `parsed_response` | Direction extracted from model output |
| `format_compliant` | Exact one-direction response |
| `correct` | Parsed response equals ground truth |
| `strict_correct` | Correct and format-compliant |

## Route fields

| Field | Meaning |
|---|---|
| `start`, `goal` | Requested route endpoints |
| `parseable` | Response could be parsed as a coordinate list |
| `starts_correctly` | First coordinate equals start |
| `reaches_goal` | Last coordinate equals goal |
| `moves_are_adjacent` | Each move is one orthogonal cell |
| `collision_free` | Every cell is traversable |
| `valid_route` | All route validity checks pass |
| `route_steps` | Number of LLM route moves |
| `optimal_steps` | A* route length |
| `optimal_route` | Valid route length equals A* length |
| `path_efficiency` | A* steps divided by LLM steps |

## Pick-and-deliver mission fields

| Field | Meaning |
|---|---|
| `instruction` | Natural-language worker request |
| `item`, `expected_item_id` | Requested pallet coordinate and identifier |
| `destination`, `expected_destination_id` | Requested dock coordinate and identifier |
| `format_compliant` | Response is exactly the required JSON object |
| `action_correct` | Action is `pick_and_deliver` |
| `item_correct` | LLM selected the requested pallet |
| `destination_correct` | LLM selected the requested dock |
| `task_correct` | Action, item and destination are all correct |
| `parseable_route` | Route field is a coordinate list |
| `starts_correctly` | Route starts at the robot |
| `reaches_destination` | Route ends at the requested dock |
| `moves_are_adjacent` | All moves are one orthogonal cell |
| `collision_free` | Route never enters a blocked cell |
| `pickup_visited` | Route visits a free cell beside the requested item |
| `valid_mission` | Task fields and complete route are correct |
| `optimal_mission` | Valid mission matches optimal two-stage A* length |
