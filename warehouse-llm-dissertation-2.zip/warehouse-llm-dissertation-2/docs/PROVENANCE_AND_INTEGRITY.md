# Provenance and academic-integrity record

## Starting material

- Supervisor-provided Colab notebook: `Qwen robot simulator - original.ipynb`
- Shared URL: <https://colab.research.google.com/drive/1PI0wc8vzWq0ptqZr4IakCpJjFhIgYGB6?usp=sharing>
- Core starting idea: a 10×10 warehouse simulator generates movement questions, Qwen 7B answers them and Python compares the response with a calculated direction.

## Material changes in this project

- Rewritten as a modular Python package
- Corrected movement to depend consistently on current facing
- Added deterministic seeds and scenario identifiers
- Added four difficulty levels
- Added controlled prompt variants
- Added natural-language pick-and-deliver task generation
- Added structured action, item and destination validation
- Added two-stage start-to-pickup-to-dock A* ground truth
- Added pickup-access validation
- Added strict and lenient direction metrics
- Added A* route ground truth
- Added route parsing, collision checking and efficiency metrics
- Added automated tests
- Added visual dashboard
- Added confidence intervals, figures and failure tables
- Added experiment and submission documentation

## Student responsibilities

Before submission, Naman should:

1. Read and understand every major module.
2. Be able to explain pose, direction, relative movement, A*, parsing and each metric.
3. Run and inspect the experiments personally.
4. Write the report in his own academic voice from genuine results.
5. Cite the supplied notebook and any literature/code used.
6. Keep a truthful record of assistance and disclose it under current University rules.
7. Avoid claiming authorship of work that the applicable policy requires him to attribute.

## Suggested factual disclosure record

Adapt this only after checking the University's required wording:

> A supervisor-provided Colab notebook was used as the starting proof of concept. Generative-AI assistance was used during software development for code structure, debugging, tests and documentation. I reviewed, executed and evaluated the resulting code, conducted the experiments, verified the reported results and take responsibility for the submitted work. Specific use was declared in accordance with the module and University requirements.

Do not use this paragraph if the official form requires different categories or wording.
