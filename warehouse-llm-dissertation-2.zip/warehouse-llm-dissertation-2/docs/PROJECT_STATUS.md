# Project status and remaining work

## Completed in this package

Project package version: **1.1.0**

- Modular warehouse simulator
- Correct relative movement and turning
- Reproducible direction-task generation
- Natural-language pick-and-deliver mission generation
- Structured action/item/destination validation
- Pickup-access and complete mission-route validation
- A* route planner and validator
- Qwen/Ollama integration
- Prompt conditions and difficulty levels
- Automatic experiment runner
- CSV/JSON logging
- Statistical summaries and figures
- Interactive demonstration interface
- Colab notebook
- Fifteen passing automated tests
- Project proposal and methodology guidance
- Dissertation, presentation and submission checklists

## Must still be completed by Naman

1. Obtain supervisor approval for the exact title and final experimental design.
2. Obtain the official University assessment brief and ethics/AI-use requirements.
3. Run the Qwen pilot and inspect its outputs.
4. Run the approved final direction, route and mission experiments.
5. Preserve the raw results and executed notebook.
6. Interpret the genuine results.
7. Conduct and cite the literature review.
8. Write the dissertation in your own academic voice.
9. Add only genuine result tables and figures.
10. Complete the University-specific declaration and submission steps.

## Why the final Qwen results are not pre-filled

The current environment does not contain the Qwen model or an active Ollama server, and experimental evidence must not be fabricated. The Colab notebook installs the required model and produces the real CSV files when Naman runs it. Oracle checks validate the software but are explicitly excluded from the dissertation results.
