# Final submission checklist

The exact University of Leeds requirements must be taken from your current module handbook and Minerva submission page. This guide explains the work package; it does not replace those official instructions.

## Phase 1 — Confirm the topic before the final experiment

- [ ] Send the working title, aim, research questions and scope to your supervisor.
- [ ] Confirm that route planning is permitted as an extension of the supplied notebook.
- [ ] Confirm whether one model is sufficient or a second model is required.
- [ ] Confirm the proposed 480 direction, 240 route and 240 mission trials per model.
- [ ] Complete any required ethics/self-assessment form.
- [ ] Record the official word limit, deadline, file formats and naming convention.
- [ ] Confirm the required AI-assistance declaration.

Do not spend days running the full experiment until these choices are approved.

## Phase 2 — Validate the software

- [ ] Run all automated tests.
- [ ] Run the oracle pipeline check and confirm 100%.
- [ ] Generate several scenarios and manually calculate them.
- [ ] Check that the displayed grid matches the prompt.
- [ ] Check that obstacles and docks behave as documented.
- [ ] Run the Qwen pilot.
- [ ] Inspect every pilot response and metric.
- [ ] Freeze the final protocol, prompts, seeds and model configuration.

## Phase 3 — Run and preserve the final experiment

- [ ] Record date, machine/runtime, Python, Ollama and model versions.
- [ ] Run the direction experiment once with the approved design.
- [ ] Run the route experiment once with the approved design.
- [ ] Run the pick-and-deliver mission experiment once with the approved design.
- [ ] Save raw CSV and JSON summaries without editing them.
- [ ] Save the executed notebook.
- [ ] Generate the analysis tables and figures.
- [ ] Back up the complete `results/final` and `results/analysis` folders.
- [ ] Calculate a checksum or create a dated read-only ZIP of the source used.
- [ ] Keep pilot and oracle outputs separate from final model results.

## Phase 4 — Complete the report

- [ ] Every research question is answered.
- [ ] Every reported number matches a raw CSV calculation.
- [ ] Tables show numerator, denominator, rate and confidence interval.
- [ ] Figures have readable labels, figure numbers and captions.
- [ ] The method states prompts, seeds, model version and temperature.
- [ ] The report credits the supervisor-supplied notebook.
- [ ] The report explains the corrected/extended parts of the software.
- [ ] Limitations include synthetic data, static obstacles and lack of a physical robot.
- [ ] No statement implies that simulator performance proves real-world safety.
- [ ] References are complete and use the required style.
- [ ] AI assistance is disclosed exactly as required by current policy.
- [ ] Appendices and source files contain no API keys, tokens or personal data.

## Phase 5 — Prepare submission files

Likely deliverables are listed below; submit only the items requested by the official page.

1. `Naman_Langa_Dissertation.pdf`
2. `Naman_Langa_Source_Code.zip`
3. `Naman_Langa_Executed_Experiments.ipynb`
4. `Naman_Langa_Results.zip`
5. Ethics or academic-integrity declaration, if separate
6. Demonstration video or slides, if requested

The source archive should contain:

- `README.md`
- `warehouse_llm/`
- `tests/`
- `streamlit_app.py`
- `analyse_results.py`
- `pyproject.toml`
- the experiment notebook
- documentation
- the step-by-step coding course and testing manual

Unless specifically requested, do not include downloaded model weights, virtual environments, caches or large temporary files.

## Phase 6 — Final technical checks

- [ ] Open the final PDF on another device.
- [ ] Check title page, page numbers, contents and figure rendering.
- [ ] Search the PDF for placeholders such as “TODO,” “XX” and “insert citation.”
- [ ] Recalculate headline results one final time.
- [ ] Extract the source ZIP into a new folder and follow the README.
- [ ] Run tests from the extracted copy.
- [ ] Remove secrets and local absolute paths.
- [ ] Check file sizes against portal limits.
- [ ] Confirm filenames and student ID requirements.

## Phase 7 — Upload

- [ ] Upload to the exact assessment area shown in Minerva.
- [ ] Wait for each file to finish and check the displayed filename.
- [ ] Use the preview to inspect the submitted PDF.
- [ ] Submit/confirm only after all required files are attached.
- [ ] Save the electronic receipt or confirmation page.
- [ ] Reopen the submission and verify the correct version appears.
- [ ] Keep the receipt and identical local files until marks are released.

Never rely on an email attachment to a supervisor unless the official instructions explicitly say that email is the submission method.

## Information still needed for an exact University-specific checklist

Provide these later and the checklist can be converted from “likely” to exact:

- module code/name;
- official assessment brief or handbook;
- Minerva submission-page screenshot;
- deadline and time zone;
- word limit;
- required reference style;
- whether code/results are separate uploads; and
- presentation/viva requirements.
