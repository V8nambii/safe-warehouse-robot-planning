from warehouse_llm.domain import Point
from warehouse_llm.planner import astar, validate_path
from warehouse_llm.warehouse import WarehouseMap


def test_astar_finds_shortest_path_around_obstacle():
    warehouse = WarehouseMap(
        width=5,
        height=5,
        objects={Point(2, 1): "Rack", Point(2, 2): "Rack", Point(2, 3): "Rack"},
    )
    path = astar(warehouse, Point(0, 2), Point(4, 2))
    assert path is not None
    check = validate_path(warehouse, path, Point(0, 2), Point(4, 2))
    assert check.valid
    assert check.steps == 8


def test_validation_rejects_collision_and_teleport():
    warehouse = WarehouseMap(width=4, height=4, objects={Point(1, 0): "Rack"})
    collision = validate_path(
        warehouse,
        [Point(0, 0), Point(1, 0), Point(2, 0)],
        Point(0, 0),
        Point(2, 0),
    )
    teleport = validate_path(
        warehouse,
        [Point(0, 0), Point(2, 0)],
        Point(0, 0),
        Point(2, 0),
    )
    assert not collision.collision_free
    assert not collision.valid
    assert not teleport.moves_are_adjacent
    assert not teleport.valid

