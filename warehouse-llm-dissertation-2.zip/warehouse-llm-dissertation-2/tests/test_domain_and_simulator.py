from warehouse_llm.domain import (
    Command,
    Direction,
    Point,
    Pose,
    RelativeDirection,
    qualitative_direction,
    turn_direction,
)
from warehouse_llm.simulator import WarehouseSimulator
from warehouse_llm.warehouse import WarehouseMap
from warehouse_llm.planner import validate_mission


def test_relative_turns_are_correct():
    assert turn_direction(Direction.NORTH, RelativeDirection.RIGHT) == Direction.EAST
    assert turn_direction(Direction.EAST, RelativeDirection.LEFT) == Direction.NORTH
    assert turn_direction(Direction.SOUTH, RelativeDirection.BACK) == Direction.NORTH


def test_movement_respects_current_facing_direction():
    simulator = WarehouseSimulator(WarehouseMap(width=5, height=5))
    north_pose = Pose(Point(2, 2), Direction.NORTH)
    east_pose = Pose(Point(2, 2), Direction.EAST)
    assert simulator.apply_command(
        north_pose, Command("move", RelativeDirection.FORWARD, 1)
    ).position == Point(2, 1)
    assert simulator.apply_command(
        east_pose, Command("move", RelativeDirection.FORWARD, 1)
    ).position == Point(3, 2)


def test_turn_changes_facing_but_not_position():
    simulator = WarehouseSimulator(WarehouseMap(width=5, height=5))
    pose = Pose(Point(2, 2), Direction.NORTH)
    result = simulator.apply_command(pose, Command("turn", RelativeDirection.RIGHT))
    assert result.position == pose.position
    assert result.facing == Direction.EAST


def test_qualitative_direction_uses_world_axes():
    assert qualitative_direction(Point(5, 5), Point(7, 2)) == Direction.NORTH_EAST
    assert qualitative_direction(Point(5, 5), Point(2, 8)) == Direction.SOUTH_WEST
    assert qualitative_direction(Point(5, 5), Point(5, 5)) is None


def test_direction_scenario_is_reproducible_and_self_consistent():
    simulator = WarehouseSimulator()
    first = simulator.generate_direction_scenario(2026, "hard")
    second = simulator.generate_direction_scenario(2026, "hard")
    assert first == second
    pose = first.start
    for command in first.commands:
        pose = simulator.apply_command(pose, command)
    assert pose == first.final_pose
    assert qualitative_direction(pose.position, first.target) == first.expected


def test_pick_and_deliver_mission_is_reproducible_and_valid():
    simulator = WarehouseSimulator()
    first = simulator.generate_mission_scenario(404, "expert")
    second = simulator.generate_mission_scenario(404, "expert")
    assert first == second
    assert first.optimal_path[0] == first.start
    assert first.optimal_path[-1] == first.destination
    check = validate_mission(simulator.warehouse, list(first.optimal_path), first)
    assert check.route.valid
    assert check.pickup_visited
    assert check.valid_route_for_mission
