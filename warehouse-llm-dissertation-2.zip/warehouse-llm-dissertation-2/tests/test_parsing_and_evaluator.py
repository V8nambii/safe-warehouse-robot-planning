from warehouse_llm.domain import Direction, Point
from warehouse_llm.evaluator import ExperimentRunner, summarize_records
from warehouse_llm.llm import OracleClient
from warehouse_llm.parsing import parse_direction, parse_mission_plan, parse_route
from warehouse_llm.simulator import WarehouseSimulator
from analyse_results import wilson_interval


def test_direction_parser_tracks_format_compliance():
    exact = parse_direction("North-East")
    explanatory = parse_direction("The answer is North-East.")
    ambiguous = parse_direction("North or South")
    assert exact.parsed == Direction.NORTH_EAST and exact.contract_valid
    assert explanatory.parsed == Direction.NORTH_EAST and not explanatory.contract_valid
    assert ambiguous.parsed is None


def test_route_parser_accepts_json_coordinates():
    assert parse_route("[[0,0],[1,0],[1,1]]") == [Point(0, 0), Point(1, 0), Point(1, 1)]
    assert parse_route("not a route") is None
    assert parse_route("[[0,0],[true,1]]") is None


def test_mission_parser_requires_task_fields_and_route():
    response = (
        '{"action":"pick_and_deliver","item_id":"P-5","destination_id":"D-3",'
        '"route":[[0,0],[1,0]]}'
    )
    parsed = parse_mission_plan(response)
    assert parsed.plan is not None and parsed.contract_valid
    assert parsed.plan.item_id == "P-5"
    assert parsed.plan.destination_id == "D-3"
    assert parsed.plan.route == [Point(0, 0), Point(1, 0)]
    assert parse_mission_plan("{}").plan is None


def test_oracle_verifies_direction_pipeline():
    runner = ExperimentRunner(WarehouseSimulator(), OracleClient())
    records = runner.run_direction(2, ["easy", "medium"], ["minimal"], base_seed=10)
    assert len(records) == 4
    assert all(record["correct"] and record["strict_correct"] for record in records)
    summary = summarize_records(records)
    assert summary["total_cases"] == 4
    assert all(row["success_rate"] == 1.0 for row in summary["conditions"])


def test_oracle_verifies_route_pipeline():
    runner = ExperimentRunner(WarehouseSimulator(), OracleClient())
    records = runner.run_routes(1, ["easy", "hard"], ["rules"], base_seed=30)
    assert len(records) == 2
    assert all(record["valid_route"] and record["optimal_route"] for record in records)


def test_oracle_verifies_pick_and_deliver_pipeline():
    runner = ExperimentRunner(WarehouseSimulator(), OracleClient())
    records = runner.run_missions(1, ["easy", "expert"], ["rules"], base_seed=60)
    assert len(records) == 2
    assert all(record["task_correct"] for record in records)
    assert all(record["valid_mission"] and record["optimal_mission"] for record in records)


def test_wilson_interval_is_bounded_and_contains_observed_rate():
    low, high = wilson_interval(7, 10)
    assert 0 <= low < 0.7 < high <= 1
