from __future__ import annotations

import heapq
from dataclasses import dataclass

from .domain import MissionScenario, Point
from .warehouse import WarehouseMap


def manhattan(a: Point, b: Point) -> int:
    return abs(a.x - b.x) + abs(a.y - b.y)


def astar(warehouse: WarehouseMap, start: Point, goal: Point) -> list[Point] | None:
    """Return an optimal four-direction path, including start and goal."""
    if not warehouse.is_free(start) or not warehouse.is_free(goal):
        return None
    frontier: list[tuple[int, int, int, Point]] = []
    counter = 0
    heapq.heappush(frontier, (manhattan(start, goal), 0, counter, start))
    came_from: dict[Point, Point | None] = {start: None}
    best_cost: dict[Point, int] = {start: 0}

    while frontier:
        _, cost, _, current = heapq.heappop(frontier)
        if current == goal:
            path: list[Point] = []
            cursor: Point | None = current
            while cursor is not None:
                path.append(cursor)
                cursor = came_from[cursor]
            return list(reversed(path))
        if cost != best_cost[current]:
            continue
        for neighbor in warehouse.neighbors4(current):
            new_cost = cost + 1
            if new_cost < best_cost.get(neighbor, 10**9):
                best_cost[neighbor] = new_cost
                came_from[neighbor] = current
                counter += 1
                priority = new_cost + manhattan(neighbor, goal)
                heapq.heappush(frontier, (priority, new_cost, counter, neighbor))
    return None


@dataclass(frozen=True)
class PathValidation:
    parseable: bool
    starts_correctly: bool
    reaches_goal: bool
    moves_are_adjacent: bool
    collision_free: bool
    steps: int | None

    @property
    def valid(self) -> bool:
        return all(
            (
                self.parseable,
                self.starts_correctly,
                self.reaches_goal,
                self.moves_are_adjacent,
                self.collision_free,
            )
        )


def validate_path(
    warehouse: WarehouseMap,
    path: list[Point] | None,
    start: Point,
    goal: Point,
) -> PathValidation:
    if not path:
        return PathValidation(False, False, False, False, False, None)
    starts_correctly = path[0] == start
    reaches_goal = path[-1] == goal
    adjacent = all(manhattan(a, b) == 1 for a, b in zip(path, path[1:]))
    collision_free = all(warehouse.is_free(point) for point in path)
    return PathValidation(True, starts_correctly, reaches_goal, adjacent, collision_free, len(path) - 1)


@dataclass(frozen=True)
class MissionValidation:
    route: PathValidation
    pickup_visited: bool
    pickup_index: int | None

    @property
    def valid_route_for_mission(self) -> bool:
        return self.route.valid and self.pickup_visited


def validate_mission(
    warehouse: WarehouseMap,
    path: list[Point] | None,
    scenario: MissionScenario,
) -> MissionValidation:
    route = validate_path(warehouse, path, scenario.start, scenario.destination)
    if not path:
        return MissionValidation(route=route, pickup_visited=False, pickup_index=None)
    pickup_set = set(scenario.pickup_points)
    pickup_index = next((index for index, point in enumerate(path[:-1]) if point in pickup_set), None)
    return MissionValidation(
        route=route,
        pickup_visited=pickup_index is not None,
        pickup_index=pickup_index,
    )
