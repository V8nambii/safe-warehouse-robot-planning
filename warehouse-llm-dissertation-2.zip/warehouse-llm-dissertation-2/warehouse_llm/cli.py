from __future__ import annotations

import argparse
import re
from pathlib import Path

from .evaluator import ExperimentRunner, save_records, save_summary, summarize_records
from .llm import OllamaClient, OracleClient, RandomBaselineClient
from .simulator import DIFFICULTY_CONFIG, WarehouseSimulator


def _csv_list(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def _client(args: argparse.Namespace):
    if args.client == "ollama":
        return OllamaClient(model=args.model, base_url=args.ollama_url, temperature=args.temperature)
    if args.client == "oracle":
        return OracleClient()
    return RandomBaselineClient(seed=args.seed)


def _slug(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_-]+", "-", value).strip("-").lower()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Warehouse LLM experiment runner")
    parser.add_argument("task", choices=("direction", "route", "mission", "all"))
    parser.add_argument("--client", choices=("ollama", "oracle", "random"), default="oracle")
    parser.add_argument("--model", default="qwen:7b")
    parser.add_argument("--ollama-url", default="http://127.0.0.1:11434")
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--cases", type=int, default=10, help="Cases per difficulty/prompt condition")
    parser.add_argument("--difficulties", default=",".join(DIFFICULTY_CONFIG))
    parser.add_argument("--styles", default="auto", help="Comma-separated styles or 'auto'")
    parser.add_argument("--seed", type=int, default=1000)
    parser.add_argument("--output-dir", default="results")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.cases < 1:
        raise SystemExit("--cases must be at least 1")
    simulator = WarehouseSimulator()
    client = _client(args)
    runner = ExperimentRunner(simulator, client)
    difficulties = _csv_list(args.difficulties)
    unknown = sorted(set(difficulties) - set(DIFFICULTY_CONFIG))
    if unknown:
        raise SystemExit(f"Unknown difficulties: {', '.join(unknown)}")
    output_dir = Path(args.output_dir)
    model_slug = _slug(client.model)
    all_records = []

    if args.task in ("direction", "all"):
        styles = (
            ["minimal", "rules", "few_shot", "distractor_map"]
            if args.styles == "auto"
            else _csv_list(args.styles)
        )
        records = runner.run_direction(args.cases, difficulties, styles, args.seed)
        save_records(records, output_dir / f"direction_{model_slug}.csv")
        save_summary(records, output_dir / f"direction_{model_slug}_summary.json")
        all_records.extend(records)

    if args.task in ("route", "all"):
        styles = (
            ["minimal", "rules", "few_shot"]
            if args.styles == "auto"
            else [style for style in _csv_list(args.styles) if style != "distractor_map"]
        )
        records = runner.run_routes(args.cases, difficulties, styles, args.seed + 100_000)
        save_records(records, output_dir / f"route_{model_slug}.csv")
        save_summary(records, output_dir / f"route_{model_slug}_summary.json")
        all_records.extend(records)

    if args.task in ("mission", "all"):
        styles = (
            ["minimal", "rules", "few_shot"]
            if args.styles == "auto"
            else [style for style in _csv_list(args.styles) if style != "distractor_map"]
        )
        records = runner.run_missions(args.cases, difficulties, styles, args.seed + 200_000)
        save_records(records, output_dir / f"mission_{model_slug}.csv")
        save_summary(records, output_dir / f"mission_{model_slug}_summary.json")
        all_records.extend(records)

    summary = summarize_records(all_records)
    print(f"Completed {summary['total_cases']} cases using {client.model}.")
    for row in summary["conditions"]:
        print(
            f"{row['task']:9s} | {row['difficulty']:6s} | {row['prompt_style']:14s} "
            f"| success={row['success_rate']:.1%} | n={row['n']}"
        )
    print(f"Results saved in: {output_dir.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
