from __future__ import annotations

import json
import re
from dataclasses import dataclass

from .domain import Direction, Point


@dataclass(frozen=True)
class DirectionParse:
    parsed: Direction | None
    contract_valid: bool


@dataclass(frozen=True)
class MissionPlan:
    action: str
    item_id: str
    destination_id: str
    route: list[Point]


@dataclass(frozen=True)
class MissionParse:
    plan: MissionPlan | None
    contract_valid: bool


def parse_direction(text: str) -> DirectionParse:
    cleaned = text.strip()
    for direction in Direction:
        if cleaned.casefold() == direction.value.casefold():
            return DirectionParse(direction, True)
    ordered = sorted(Direction, key=lambda direction: len(direction.value), reverse=True)
    alternatives = "|".join(re.escape(direction.value) for direction in ordered)
    found = re.findall(rf"(?<![A-Za-z])({alternatives})(?![A-Za-z])", cleaned, re.I)
    matches = [next(direction for direction in Direction if direction.value.casefold() == item.casefold()) for item in found]
    return DirectionParse(matches[0] if len(matches) == 1 else None, False)


def parse_route(text: str, max_points: int = 500) -> list[Point] | None:
    candidate = text.strip()
    try:
        data = json.loads(candidate)
    except json.JSONDecodeError:
        start = candidate.find("[")
        end = candidate.rfind("]")
        if start < 0 or end <= start:
            return None
        try:
            data = json.loads(candidate[start : end + 1])
        except json.JSONDecodeError:
            return None
    if not isinstance(data, list) or not data or len(data) > max_points:
        return None
    points: list[Point] = []
    for item in data:
        if (
            not isinstance(item, list)
            or len(item) != 2
            or not all(isinstance(value, int) and not isinstance(value, bool) for value in item)
        ):
            return None
        points.append(Point(item[0], item[1]))
    return points


def parse_mission_plan(text: str, max_points: int = 500) -> MissionParse:
    candidate = text.strip()
    try:
        data = json.loads(candidate)
    except json.JSONDecodeError:
        start = candidate.find("{")
        end = candidate.rfind("}")
        if start < 0 or end <= start:
            return MissionParse(None, False)
        try:
            data = json.loads(candidate[start : end + 1])
        except json.JSONDecodeError:
            return MissionParse(None, False)
    if not isinstance(data, dict):
        return MissionParse(None, False)
    action = data.get("action")
    item_id = data.get("item_id")
    destination_id = data.get("destination_id")
    route_data = data.get("route")
    if not all(isinstance(value, str) for value in (action, item_id, destination_id)):
        return MissionParse(None, False)
    route = parse_route(json.dumps(route_data), max_points=max_points)
    if route is None:
        return MissionParse(None, False)
    required = {"action", "item_id", "destination_id", "route"}
    contract_valid = set(data) == required and candidate.startswith("{") and candidate.endswith("}")
    return MissionParse(
        MissionPlan(
            action=action,
            item_id=item_id,
            destination_id=destination_id,
            route=route,
        ),
        contract_valid,
    )
