from __future__ import annotations

import matplotlib.pyplot as plt
from matplotlib.axes import Axes
from matplotlib.figure import Figure
from matplotlib.patches import Rectangle

from .domain import DirectionScenario, MissionScenario, Point, RouteScenario
from .warehouse import WarehouseMap


def _base_grid(warehouse: WarehouseMap) -> tuple[Figure, Axes]:
    fig, ax = plt.subplots(figsize=(7, 7))
    ax.set_xlim(-0.5, warehouse.width - 0.5)
    ax.set_ylim(warehouse.height - 0.5, -0.5)
    ax.set_xticks(range(warehouse.width))
    ax.set_yticks(range(warehouse.height))
    ax.set_xticks([value - 0.5 for value in range(warehouse.width + 1)], minor=True)
    ax.set_yticks([value - 0.5 for value in range(warehouse.height + 1)], minor=True)
    ax.grid(which="minor", color="#cbd5e1", linewidth=0.8)
    ax.tick_params(which="minor", bottom=False, left=False)
    ax.set_xlabel("x (East →)")
    ax.set_ylabel("y (South ↓)")
    for point, label in warehouse.objects.items():
        if warehouse.is_blocked(point):
            color = "#334155" if label.startswith(("Rack", "Column")) else "#94a3b8"
            ax.add_patch(Rectangle((point.x - 0.48, point.y - 0.48), 0.96, 0.96, color=color))
        else:
            ax.add_patch(
                Rectangle(
                    (point.x - 0.48, point.y - 0.48), 0.96, 0.96,
                    facecolor="#bae6fd", edgecolor="#0284c7", linewidth=1.2,
                )
            )
    return fig, ax


def plot_direction_scenario(
    warehouse: WarehouseMap,
    scenario: DirectionScenario,
) -> Figure:
    fig, ax = _base_grid(warehouse)
    ax.scatter(
        scenario.start.position.x,
        scenario.start.position.y,
        s=170,
        marker="o",
        color="#2563eb",
        label=f"Start ({scenario.start.facing.value})",
        zorder=4,
    )
    ax.scatter(
        scenario.final_pose.position.x,
        scenario.final_pose.position.y,
        s=190,
        marker="*",
        color="#16a34a",
        label="Final position",
        zorder=5,
    )
    ax.scatter(
        scenario.target.x,
        scenario.target.y,
        s=180,
        marker="X",
        color="#dc2626",
        label="Target",
        zorder=6,
    )
    ax.plot(
        [scenario.final_pose.position.x, scenario.target.x],
        [scenario.final_pose.position.y, scenario.target.y],
        linestyle="--",
        color="#ef4444",
        linewidth=1.5,
        alpha=0.8,
    )
    ax.set_title(f"Direction task — answer: {scenario.expected.value}")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.10), ncol=3)
    fig.tight_layout()
    return fig


def plot_route_scenario(
    warehouse: WarehouseMap,
    scenario: RouteScenario,
    candidate_path: list[Point] | None = None,
) -> Figure:
    fig, ax = _base_grid(warehouse)
    optimal_x = [point.x for point in scenario.optimal_path]
    optimal_y = [point.y for point in scenario.optimal_path]
    ax.plot(optimal_x, optimal_y, color="#16a34a", linewidth=3, label="A* optimal route", zorder=4)
    if candidate_path:
        ax.plot(
            [point.x for point in candidate_path],
            [point.y for point in candidate_path],
            color="#f97316",
            linewidth=2,
            linestyle="--",
            label="LLM route",
            zorder=5,
        )
    ax.scatter(scenario.start.x, scenario.start.y, s=170, color="#2563eb", label="Start", zorder=6)
    ax.scatter(scenario.goal.x, scenario.goal.y, s=190, marker="*", color="#dc2626", label="Goal", zorder=6)
    ax.set_title(f"Route task — optimal length: {scenario.optimal_steps} steps")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.10), ncol=4)
    fig.tight_layout()
    return fig


def plot_mission_scenario(
    warehouse: WarehouseMap,
    scenario: MissionScenario,
    candidate_path: list[Point] | None = None,
) -> Figure:
    fig, ax = _base_grid(warehouse)
    optimal_x = [point.x for point in scenario.optimal_path]
    optimal_y = [point.y for point in scenario.optimal_path]
    ax.plot(
        optimal_x, optimal_y, color="#16a34a", linewidth=3,
        label="A* pick-and-deliver route", zorder=4,
    )
    if candidate_path:
        ax.plot(
            [point.x for point in candidate_path],
            [point.y for point in candidate_path],
            color="#f97316", linewidth=2, linestyle="--", label="LLM mission route", zorder=5,
        )
    ax.scatter(
        scenario.start.x, scenario.start.y, s=170, color="#2563eb", label="Robot start", zorder=6
    )
    ax.scatter(
        scenario.item.x, scenario.item.y, s=190, marker="X", color="#facc15",
        edgecolors="#713f12", label=f"Item {scenario.item_id}", zorder=7,
    )
    ax.scatter(
        scenario.optimal_pickup.x, scenario.optimal_pickup.y, s=160, marker="D",
        color="#a855f7", label="Optimal pickup access", zorder=7,
    )
    ax.scatter(
        scenario.destination.x, scenario.destination.y, s=210, marker="*", color="#dc2626",
        label=f"Dock {scenario.destination_id}", zorder=7,
    )
    ax.set_title(f"Pick-and-deliver mission — optimal: {scenario.optimal_steps} steps")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.10), ncol=3)
    fig.tight_layout()
    return fig
