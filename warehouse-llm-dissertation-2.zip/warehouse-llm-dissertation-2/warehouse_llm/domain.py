from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


@dataclass(frozen=True, order=True)
class Point:
    x: int
    y: int

    def moved(self, dx: int, dy: int, steps: int = 1) -> "Point":
        return Point(self.x + dx * steps, self.y + dy * steps)

    def as_tuple(self) -> tuple[int, int]:
        return self.x, self.y

    def as_list(self) -> list[int]:
        return [self.x, self.y]


class Direction(str, Enum):
    NORTH = "North"
    NORTH_EAST = "North-East"
    EAST = "East"
    SOUTH_EAST = "South-East"
    SOUTH = "South"
    SOUTH_WEST = "South-West"
    WEST = "West"
    NORTH_WEST = "North-West"


DIRECTION_ORDER: tuple[Direction, ...] = tuple(Direction)
DIRECTION_VECTORS: dict[Direction, tuple[int, int]] = {
    Direction.NORTH: (0, -1),
    Direction.NORTH_EAST: (1, -1),
    Direction.EAST: (1, 0),
    Direction.SOUTH_EAST: (1, 1),
    Direction.SOUTH: (0, 1),
    Direction.SOUTH_WEST: (-1, 1),
    Direction.WEST: (-1, 0),
    Direction.NORTH_WEST: (-1, -1),
}


class RelativeDirection(str, Enum):
    FORWARD = "Forward"
    FORWARD_RIGHT = "Forward-Right"
    RIGHT = "Right"
    BACK_RIGHT = "Back-Right"
    BACK = "Back"
    BACK_LEFT = "Back-Left"
    LEFT = "Left"
    FORWARD_LEFT = "Forward-Left"


RELATIVE_TURN_OFFSETS: dict[RelativeDirection, int] = {
    RelativeDirection.FORWARD: 0,
    RelativeDirection.FORWARD_RIGHT: 1,
    RelativeDirection.RIGHT: 2,
    RelativeDirection.BACK_RIGHT: 3,
    RelativeDirection.BACK: 4,
    RelativeDirection.BACK_LEFT: 5,
    RelativeDirection.LEFT: 6,
    RelativeDirection.FORWARD_LEFT: 7,
}


def turn_direction(facing: Direction, relative: RelativeDirection) -> Direction:
    index = DIRECTION_ORDER.index(facing)
    return DIRECTION_ORDER[(index + RELATIVE_TURN_OFFSETS[relative]) % 8]


def qualitative_direction(origin: Point, target: Point) -> Direction | None:
    dx = target.x - origin.x
    dy = target.y - origin.y
    sx = 0 if dx == 0 else (1 if dx > 0 else -1)
    sy = 0 if dy == 0 else (1 if dy > 0 else -1)
    if (sx, sy) == (0, 0):
        return None
    for direction, vector in DIRECTION_VECTORS.items():
        if vector == (sx, sy):
            return direction
    raise RuntimeError("Unreachable direction")


@dataclass(frozen=True)
class Pose:
    position: Point
    facing: Direction


@dataclass(frozen=True)
class Command:
    kind: str  # "move" or "turn"
    relative: RelativeDirection
    steps: int = 0

    def text(self) -> str:
        if self.kind == "turn":
            return f"Turn to face {self.relative.value} relative to your current facing direction."
        unit = "step" if self.steps == 1 else "steps"
        return f"Move {self.steps} {unit} {self.relative.value}."


@dataclass(frozen=True)
class DirectionScenario:
    scenario_id: str
    seed: int
    difficulty: str
    start: Pose
    commands: tuple[Command, ...]
    final_pose: Pose
    target: Point
    target_label: str
    expected: Direction

    def metadata(self) -> dict[str, Any]:
        return {
            "scenario_id": self.scenario_id,
            "seed": self.seed,
            "difficulty": self.difficulty,
            "instruction_count": len(self.commands),
            "start": self.start.position.as_tuple(),
            "start_facing": self.start.facing.value,
            "final": self.final_pose.position.as_tuple(),
            "final_facing": self.final_pose.facing.value,
            "target": self.target.as_tuple(),
            "target_label": self.target_label,
            "expected": self.expected.value,
        }


@dataclass(frozen=True)
class RouteScenario:
    scenario_id: str
    seed: int
    difficulty: str
    start: Point
    goal: Point
    optimal_path: tuple[Point, ...]

    @property
    def optimal_steps(self) -> int:
        return len(self.optimal_path) - 1


@dataclass(frozen=True)
class MissionScenario:
    """A pick-and-deliver job combining language understanding and navigation."""

    scenario_id: str
    seed: int
    difficulty: str
    start: Point
    item: Point
    item_id: str
    item_label: str
    destination: Point
    destination_id: str
    destination_label: str
    pickup_points: tuple[Point, ...]
    optimal_pickup: Point
    optimal_path: tuple[Point, ...]
    instruction: str

    @property
    def optimal_steps(self) -> int:
        return len(self.optimal_path) - 1
