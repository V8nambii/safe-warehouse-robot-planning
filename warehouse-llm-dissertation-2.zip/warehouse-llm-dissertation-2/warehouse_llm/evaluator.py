from __future__ import annotations

import csv
import json
from collections import defaultdict
from pathlib import Path
from statistics import mean
from typing import Any, Iterable

from .llm import LLMClient
from .parsing import parse_direction, parse_mission_plan, parse_route
from .planner import validate_mission, validate_path
from .prompts import build_direction_prompt, build_mission_prompt, build_route_prompt
from .simulator import WarehouseSimulator


class ExperimentRunner:
    def __init__(self, simulator: WarehouseSimulator, client: LLMClient):
        self.simulator = simulator
        self.client = client

    def run_direction(
        self,
        cases_per_condition: int,
        difficulties: Iterable[str],
        prompt_styles: Iterable[str],
        base_seed: int = 1000,
    ) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        index = 0
        for difficulty in difficulties:
            for style in prompt_styles:
                for _ in range(cases_per_condition):
                    seed = base_seed + index
                    index += 1
                    scenario = self.simulator.generate_direction_scenario(seed, difficulty)
                    prompt = build_direction_prompt(scenario, self.simulator.warehouse, style)
                    response = self.client.generate(prompt, context=scenario)
                    parsed = parse_direction(response.text)
                    record = scenario.metadata()
                    record.update(
                        {
                            "task": "direction",
                            "prompt_style": style,
                            "model": response.model,
                            "raw_response": response.text,
                            "parsed_response": parsed.parsed.value if parsed.parsed else None,
                            "format_compliant": parsed.contract_valid,
                            "correct": parsed.parsed == scenario.expected,
                            "strict_correct": parsed.contract_valid and parsed.parsed == scenario.expected,
                            "latency_ms": round(response.latency_ms, 3),
                            "prompt_characters": len(prompt),
                        }
                    )
                    records.append(record)
        return records

    def run_routes(
        self,
        cases_per_condition: int,
        difficulties: Iterable[str],
        prompt_styles: Iterable[str],
        base_seed: int = 5000,
    ) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        index = 0
        for difficulty in difficulties:
            for style in prompt_styles:
                for _ in range(cases_per_condition):
                    seed = base_seed + index
                    index += 1
                    scenario = self.simulator.generate_route_scenario(seed, difficulty)
                    prompt = build_route_prompt(scenario, self.simulator.warehouse, style)
                    response = self.client.generate(prompt, context=scenario)
                    path = parse_route(response.text)
                    validation = validate_path(
                        self.simulator.warehouse, path, scenario.start, scenario.goal
                    )
                    efficiency = 0.0
                    if validation.valid and validation.steps is not None and validation.steps > 0:
                        efficiency = scenario.optimal_steps / validation.steps
                    records.append(
                        {
                            "scenario_id": scenario.scenario_id,
                            "seed": seed,
                            "task": "route",
                            "difficulty": difficulty,
                            "prompt_style": style,
                            "model": response.model,
                            "start": scenario.start.as_tuple(),
                            "goal": scenario.goal.as_tuple(),
                            "raw_response": response.text,
                            "parseable": validation.parseable,
                            "starts_correctly": validation.starts_correctly,
                            "reaches_goal": validation.reaches_goal,
                            "moves_are_adjacent": validation.moves_are_adjacent,
                            "collision_free": validation.collision_free,
                            "valid_route": validation.valid,
                            "route_steps": validation.steps,
                            "optimal_steps": scenario.optimal_steps,
                            "optimal_route": validation.valid
                            and validation.steps == scenario.optimal_steps,
                            "path_efficiency": round(efficiency, 4),
                            "latency_ms": round(response.latency_ms, 3),
                            "prompt_characters": len(prompt),
                        }
                    )
        return records

    def run_missions(
        self,
        cases_per_condition: int,
        difficulties: Iterable[str],
        prompt_styles: Iterable[str],
        base_seed: int = 9000,
    ) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        index = 0
        for difficulty in difficulties:
            for style in prompt_styles:
                for _ in range(cases_per_condition):
                    seed = base_seed + index
                    index += 1
                    scenario = self.simulator.generate_mission_scenario(seed, difficulty)
                    prompt = build_mission_prompt(scenario, self.simulator.warehouse, style)
                    response = self.client.generate(prompt, context=scenario)
                    parsed = parse_mission_plan(response.text)
                    plan = parsed.plan
                    action_correct = bool(plan and plan.action == "pick_and_deliver")
                    item_correct = bool(plan and plan.item_id.casefold() == scenario.item_id.casefold())
                    destination_correct = bool(
                        plan and plan.destination_id.casefold() == scenario.destination_id.casefold()
                    )
                    task_correct = action_correct and item_correct and destination_correct
                    mission_check = validate_mission(
                        self.simulator.warehouse,
                        plan.route if plan else None,
                        scenario,
                    )
                    valid_mission = task_correct and mission_check.valid_route_for_mission
                    route_steps = mission_check.route.steps
                    efficiency = 0.0
                    if valid_mission and route_steps and route_steps > 0:
                        efficiency = scenario.optimal_steps / route_steps
                    records.append(
                        {
                            "scenario_id": scenario.scenario_id,
                            "seed": seed,
                            "task": "mission",
                            "difficulty": difficulty,
                            "prompt_style": style,
                            "model": response.model,
                            "instruction": scenario.instruction,
                            "start": scenario.start.as_tuple(),
                            "item": scenario.item.as_tuple(),
                            "expected_item_id": scenario.item_id,
                            "destination": scenario.destination.as_tuple(),
                            "expected_destination_id": scenario.destination_id,
                            "raw_response": response.text,
                            "format_compliant": parsed.contract_valid,
                            "action_correct": action_correct,
                            "item_correct": item_correct,
                            "destination_correct": destination_correct,
                            "task_correct": task_correct,
                            "parseable_route": mission_check.route.parseable,
                            "starts_correctly": mission_check.route.starts_correctly,
                            "reaches_destination": mission_check.route.reaches_goal,
                            "moves_are_adjacent": mission_check.route.moves_are_adjacent,
                            "collision_free": mission_check.route.collision_free,
                            "pickup_visited": mission_check.pickup_visited,
                            "valid_mission": valid_mission,
                            "route_steps": route_steps,
                            "optimal_steps": scenario.optimal_steps,
                            "optimal_mission": valid_mission and route_steps == scenario.optimal_steps,
                            "path_efficiency": round(efficiency, 4),
                            "latency_ms": round(response.latency_ms, 3),
                            "prompt_characters": len(prompt),
                        }
                    )
        return records


def save_records(records: list[dict[str, Any]], output_csv: str | Path) -> Path:
    if not records:
        raise ValueError("No records to save")
    path = Path(output_csv)
    path.parent.mkdir(parents=True, exist_ok=True)
    keys: list[str] = []
    for record in records:
        for key in record:
            if key not in keys:
                keys.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(records)
    return path


def summarize_records(records: list[dict[str, Any]]) -> dict[str, Any]:
    grouped: dict[tuple[str, str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        key = (
            str(record.get("task")),
            str(record.get("model")),
            str(record.get("difficulty")),
            str(record.get("prompt_style")),
        )
        grouped[key].append(record)
    rows: list[dict[str, Any]] = []
    for (task, model, difficulty, style), group in sorted(grouped.items()):
        if task == "direction":
            success_key = "correct"
        elif task == "mission":
            success_key = "valid_mission"
        else:
            success_key = "valid_route"
        row: dict[str, Any] = {
            "task": task,
            "model": model,
            "difficulty": difficulty,
            "prompt_style": style,
            "n": len(group),
            "success_rate": round(mean(bool(item.get(success_key)) for item in group), 4),
            "mean_latency_ms": round(mean(float(item.get("latency_ms", 0)) for item in group), 3),
        }
        if task == "direction":
            row["strict_accuracy"] = round(
                mean(bool(item.get("strict_correct")) for item in group), 4
            )
            row["format_compliance"] = round(
                mean(bool(item.get("format_compliant")) for item in group), 4
            )
        elif task == "route":
            row["optimal_route_rate"] = round(
                mean(bool(item.get("optimal_route")) for item in group), 4
            )
            row["mean_path_efficiency"] = round(
                mean(float(item.get("path_efficiency", 0)) for item in group), 4
            )
        else:
            row["task_accuracy"] = round(
                mean(bool(item.get("task_correct")) for item in group), 4
            )
            row["pickup_visit_rate"] = round(
                mean(bool(item.get("pickup_visited")) for item in group), 4
            )
            row["optimal_mission_rate"] = round(
                mean(bool(item.get("optimal_mission")) for item in group), 4
            )
            row["mean_path_efficiency"] = round(
                mean(float(item.get("path_efficiency", 0)) for item in group), 4
            )
        rows.append(row)
    return {"conditions": rows, "total_cases": len(records)}


def save_summary(records: list[dict[str, Any]], output_json: str | Path) -> Path:
    path = Path(output_json)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(summarize_records(records), indent=2), encoding="utf-8")
    return path
