from __future__ import annotations

from .domain import Direction, DirectionScenario, MissionScenario, RouteScenario
from .warehouse import WarehouseMap


VALID_DIRECTIONS = ", ".join(direction.value for direction in Direction)


def direction_question(scenario: DirectionScenario) -> str:
    lines = [
        f"Start at ({scenario.start.position.x},{scenario.start.position.y}), "
        f"facing {scenario.start.facing.value}.",
    ]
    lines.extend(f"{index}. {command.text()}" for index, command in enumerate(scenario.commands, start=1))
    lines.append(
        f"Target {scenario.target_label} is at ({scenario.target.x},{scenario.target.y})."
    )
    lines.append("What is the world compass direction from your final position to the target?")
    return "\n".join(lines)


def build_direction_prompt(
    scenario: DirectionScenario,
    warehouse: WarehouseMap,
    style: str = "rules",
) -> str:
    question = direction_question(scenario)
    contract = (
        "Return exactly one of these values and nothing else:\n"
        f"{VALID_DIRECTIONS}\n"
    )
    conventions = (
        "Coordinate rules:\n"
        "- The origin (0,0) is the top-left corner.\n"
        "- Increasing x moves East; increasing y moves South.\n"
        "- Movement words are relative to the robot's current facing direction.\n"
        "- Turning changes facing but does not change position.\n"
        "- World compass directions remain fixed.\n"
    )
    if style == "minimal":
        return f"{question}\n\n{contract}"
    if style == "rules":
        return f"You solve warehouse spatial-reasoning tasks.\n{conventions}\n{question}\n\n{contract}"
    if style == "few_shot":
        example = (
            "Example:\n"
            "Start at (2,2), facing North.\n"
            "1. Move 1 step Right.\n"
            "Target Example Box is at (2,0).\n"
            "The robot finishes at (3,2), so the required output is North-West.\n"
        )
        return f"You solve warehouse spatial-reasoning tasks.\n{conventions}\n{example}\n{question}\n\n{contract}"
    if style == "distractor_map":
        return (
            "You solve warehouse spatial-reasoning tasks.\n"
            f"{conventions}\nWarehouse object map:\n{warehouse.object_lines()}\n\n"
            f"{question}\n\n{contract}"
        )
    raise ValueError(f"Unknown direction prompt style: {style}")


def build_route_prompt(
    scenario: RouteScenario,
    warehouse: WarehouseMap,
    style: str = "rules",
) -> str:
    blocked = sorted(warehouse.blocked_points(), key=lambda point: (point.y, point.x))
    blocked_text = ", ".join(f"[{p.x},{p.y}]" for p in blocked)
    task = (
        f"Grid size: {warehouse.width} columns by {warehouse.height} rows.\n"
        f"Start: [{scenario.start.x},{scenario.start.y}]\n"
        f"Goal: [{scenario.goal.x},{scenario.goal.y}]\n"
        f"Blocked cells: [{blocked_text}]\n"
    )
    contract = (
        "Return only a JSON array of coordinates, including start and goal. "
        "Example format: [[0,0],[1,0],[2,0]]. Do not use markdown or explanation."
    )
    rules = (
        "The robot may move one cell at a time only North, East, South or West. "
        "It may not leave the grid or enter a blocked cell. Find a shortest valid route."
    )
    if style == "minimal":
        return f"Find a route for a warehouse robot.\n{task}\n{contract}"
    if style == "rules":
        return f"Plan a safe warehouse robot route.\n{rules}\n{task}\n{contract}"
    if style == "few_shot":
        example = (
            "Example: on a 3x3 empty grid, Start [0,0], Goal [2,0]. "
            "Correct output: [[0,0],[1,0],[2,0]]."
        )
        return f"Plan a safe warehouse robot route.\n{rules}\n{example}\n{task}\n{contract}"
    raise ValueError(f"Unknown route prompt style: {style}")


def build_mission_prompt(
    scenario: MissionScenario,
    warehouse: WarehouseMap,
    style: str = "rules",
) -> str:
    blocked = sorted(warehouse.blocked_points(), key=lambda point: (point.y, point.x))
    blocked_text = ", ".join(f"[{point.x},{point.y}]" for point in blocked)
    facts = (
        f"Warehouse size: {warehouse.width} by {warehouse.height}.\n"
        f"Robot start: [{scenario.start.x},{scenario.start.y}]\n"
        f"Requested item: {scenario.item_label} at [{scenario.item.x},{scenario.item.y}]\n"
        f"Destination: {scenario.destination_label} at "
        f"[{scenario.destination.x},{scenario.destination.y}]\n"
        f"Blocked cells: [{blocked_text}]\n"
        f"Worker instruction: {scenario.instruction}\n"
    )
    schema = (
        "Return only one JSON object with exactly these keys:\n"
        '{"action":"pick_and_deliver","item_id":"P-x",'
        '"destination_id":"D-x","route":[[x,y],[x,y]]}\n'
        "Do not include markdown or explanation."
    )
    rules = (
        "Planning rules:\n"
        "- Use the item and destination identifiers requested by the worker.\n"
        "- Start the route at the robot start coordinate.\n"
        "- Move one cell at a time only North, East, South or West.\n"
        "- Do not leave the grid or enter a blocked cell.\n"
        "- The item cell is blocked: visit a free orthogonally adjacent cell to pick it.\n"
        "- Visit the pickup-access cell before ending at the destination dock.\n"
        "- Prefer a shortest valid route.\n"
    )
    if style == "minimal":
        return f"Create a warehouse pick-and-deliver plan.\n{facts}\n{schema}"
    if style == "rules":
        return f"Create a safe warehouse pick-and-deliver plan.\n{rules}\n{facts}\n{schema}"
    if style == "few_shot":
        example = (
            "Small example: Start [0,0], item P-1 at blocked cell [2,0], destination D-1 "
            "at [2,2], with no other blocked cells. A valid answer is "
            '{"action":"pick_and_deliver","item_id":"P-1","destination_id":"D-1",'
            '"route":[[0,0],[1,0],[1,1],[2,1],[2,2]]}.\n'
        )
        return (
            f"Create a safe warehouse pick-and-deliver plan.\n{rules}\n{example}\n"
            f"{facts}\n{schema}"
        )
    raise ValueError(f"Unknown mission prompt style: {style}")
