from __future__ import annotations

import random

from .domain import (
    DIRECTION_VECTORS,
    Command,
    Direction,
    DirectionScenario,
    MissionScenario,
    Point,
    Pose,
    RelativeDirection,
    RouteScenario,
    qualitative_direction,
    turn_direction,
)
from .planner import astar, manhattan
from .warehouse import WarehouseMap, default_warehouse, object_identifier


DIFFICULTY_CONFIG: dict[str, dict[str, float | int]] = {
    "easy": {"instructions": 1, "max_move": 1, "turn_probability": 0.0, "min_route": 3},
    "medium": {"instructions": 3, "max_move": 2, "turn_probability": 0.25, "min_route": 6},
    "hard": {"instructions": 5, "max_move": 3, "turn_probability": 0.35, "min_route": 9},
    "expert": {"instructions": 7, "max_move": 3, "turn_probability": 0.45, "min_route": 12},
}


class WarehouseSimulator:
    def __init__(self, warehouse: WarehouseMap | None = None):
        self.warehouse = warehouse or default_warehouse()

    def apply_command(self, pose: Pose, command: Command) -> Pose:
        if command.kind == "turn":
            return Pose(pose.position, turn_direction(pose.facing, command.relative))
        move_direction = turn_direction(pose.facing, command.relative)
        dx, dy = DIRECTION_VECTORS[move_direction]
        current = pose.position
        for _ in range(command.steps):
            candidate = current.moved(dx, dy)
            if not self.warehouse.is_free(candidate):
                raise ValueError(f"Invalid movement into blocked/out-of-bounds cell {candidate}")
            current = candidate
        return Pose(current, pose.facing)

    def possible_moves(self, pose: Pose, max_steps: int) -> list[Command]:
        possible: list[Command] = []
        for relative in RelativeDirection:
            direction = turn_direction(pose.facing, relative)
            dx, dy = DIRECTION_VECTORS[direction]
            current = pose.position
            for steps in range(1, max_steps + 1):
                current = current.moved(dx, dy)
                if not self.warehouse.is_free(current):
                    break
                possible.append(Command("move", relative, steps))
        return possible

    def generate_direction_scenario(self, seed: int, difficulty: str = "medium") -> DirectionScenario:
        if difficulty not in DIFFICULTY_CONFIG:
            raise ValueError(f"Unknown difficulty: {difficulty}")
        config = DIFFICULTY_CONFIG[difficulty]
        rng = random.Random(seed)
        free = self.warehouse.free_points()

        for attempt in range(200):
            start = Pose(rng.choice(free), rng.choice(tuple(Direction)))
            pose = start
            commands: list[Command] = []
            for index in range(int(config["instructions"])):
                should_turn = (
                    index > 0
                    and rng.random() < float(config["turn_probability"])
                )
                moves = self.possible_moves(pose, int(config["max_move"]))
                if should_turn or not moves:
                    relative = rng.choice(tuple(r for r in RelativeDirection if r != RelativeDirection.FORWARD))
                    command = Command("turn", relative)
                else:
                    command = rng.choice(moves)
                pose = self.apply_command(pose, command)
                commands.append(command)

            targets = [point for point in self.warehouse.objects if point != pose.position]
            rng.shuffle(targets)
            for target in targets:
                expected = qualitative_direction(pose.position, target)
                if expected is not None:
                    label = self.warehouse.objects[target]
                    return DirectionScenario(
                        scenario_id=f"DIR-{difficulty.upper()}-{seed}-{attempt}",
                        seed=seed,
                        difficulty=difficulty,
                        start=start,
                        commands=tuple(commands),
                        final_pose=pose,
                        target=target,
                        target_label=label,
                        expected=expected,
                    )
        raise RuntimeError("Could not generate a valid direction scenario")

    def generate_route_scenario(self, seed: int, difficulty: str = "medium") -> RouteScenario:
        if difficulty not in DIFFICULTY_CONFIG:
            raise ValueError(f"Unknown difficulty: {difficulty}")
        config = DIFFICULTY_CONFIG[difficulty]
        rng = random.Random(seed)
        free = self.warehouse.free_points()
        min_route = int(config["min_route"])

        fallback: tuple[Point, Point, list[Point]] | None = None
        for attempt in range(500):
            start, goal = rng.sample(free, 2)
            if manhattan(start, goal) < max(2, min_route // 2):
                continue
            path = astar(self.warehouse, start, goal)
            if path is None:
                continue
            fallback = (start, goal, path)
            if len(path) - 1 >= min_route:
                return RouteScenario(
                    scenario_id=f"ROUTE-{difficulty.upper()}-{seed}-{attempt}",
                    seed=seed,
                    difficulty=difficulty,
                    start=start,
                    goal=goal,
                    optimal_path=tuple(path),
                )
        if fallback:
            start, goal, path = fallback
            return RouteScenario(
                scenario_id=f"ROUTE-{difficulty.upper()}-{seed}-fallback",
                seed=seed,
                difficulty=difficulty,
                start=start,
                goal=goal,
                optimal_path=tuple(path),
            )
        raise RuntimeError("Could not generate a connected route scenario")

    def _mission_instruction(
        self,
        item_id: str,
        item_label: str,
        destination_id: str,
        destination_label: str,
        difficulty: str,
    ) -> str:
        product = item_label.removeprefix(f"Pallet {item_id} ").strip("()")
        if difficulty == "easy":
            return f"Pick pallet {item_id} and deliver it to dock {destination_id}."
        if difficulty == "medium":
            return (
                f"Collect {product} from pallet {item_id}, then take it to "
                f"{destination_label}."
            )
        if difficulty == "hard":
            return (
                f"Prepare an outbound job for {product}. Retrieve inventory unit {item_id} "
                f"and complete its delivery at destination {destination_id}."
            )
        return (
            f"Ignore unrelated racks and forklifts. The requested SKU is the {product} stored "
            f"as {item_id}; it must finish at {destination_id}, not at any other dock. "
            "Create the pick-and-deliver plan."
        )

    def generate_mission_scenario(self, seed: int, difficulty: str = "medium") -> MissionScenario:
        """Generate a pick-and-deliver task with an optimal two-stage A* path."""
        if difficulty not in DIFFICULTY_CONFIG:
            raise ValueError(f"Unknown difficulty: {difficulty}")
        rng = random.Random(seed)
        min_route = int(DIFFICULTY_CONFIG[difficulty]["min_route"])
        pallets = self.warehouse.pallet_objects()
        docks = self.warehouse.dock_objects()
        free = self.warehouse.free_points()
        fallback: tuple[
            Point, Point, str, Point, str, tuple[Point, ...], Point, list[Point]
        ] | None = None

        for attempt in range(800):
            item, item_label = rng.choice(pallets)
            destination, destination_label = rng.choice(docks)
            start = rng.choice(free)
            pickup_points = tuple(self.warehouse.access_points(item))
            if not pickup_points or start == destination:
                continue

            candidates: list[tuple[int, Point, list[Point]]] = []
            for pickup in pickup_points:
                to_pickup = astar(self.warehouse, start, pickup)
                to_destination = astar(self.warehouse, pickup, destination)
                if to_pickup is None or to_destination is None:
                    continue
                combined = to_pickup + to_destination[1:]
                candidates.append((len(combined) - 1, pickup, combined))
            if not candidates:
                continue
            _, optimal_pickup, optimal_path = min(candidates, key=lambda candidate: candidate[0])
            fallback = (
                start, item, item_label, destination, destination_label,
                pickup_points, optimal_pickup, optimal_path,
            )
            if len(optimal_path) - 1 < min_route:
                continue
            item_id = object_identifier(item_label)
            destination_id = object_identifier(destination_label)
            return MissionScenario(
                scenario_id=f"MISSION-{difficulty.upper()}-{seed}-{attempt}",
                seed=seed,
                difficulty=difficulty,
                start=start,
                item=item,
                item_id=item_id,
                item_label=item_label,
                destination=destination,
                destination_id=destination_id,
                destination_label=destination_label,
                pickup_points=pickup_points,
                optimal_pickup=optimal_pickup,
                optimal_path=tuple(optimal_path),
                instruction=self._mission_instruction(
                    item_id, item_label, destination_id, destination_label, difficulty
                ),
            )
        if fallback:
            (
                start, item, item_label, destination, destination_label,
                pickup_points, optimal_pickup, optimal_path,
            ) = fallback
            item_id = object_identifier(item_label)
            destination_id = object_identifier(destination_label)
            return MissionScenario(
                scenario_id=f"MISSION-{difficulty.upper()}-{seed}-fallback",
                seed=seed,
                difficulty=difficulty,
                start=start,
                item=item,
                item_id=item_id,
                item_label=item_label,
                destination=destination,
                destination_id=destination_id,
                destination_label=destination_label,
                pickup_points=pickup_points,
                optimal_pickup=optimal_pickup,
                optimal_path=tuple(optimal_path),
                instruction=self._mission_instruction(
                    item_id, item_label, destination_id, destination_label, difficulty
                ),
            )
        raise RuntimeError("Could not generate a connected pick-and-deliver mission")
