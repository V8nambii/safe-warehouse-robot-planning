from __future__ import annotations

import json
import random
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Protocol

from .domain import Direction, DirectionScenario, MissionScenario, RouteScenario


@dataclass(frozen=True)
class LLMResponse:
    text: str
    model: str
    latency_ms: float


class LLMClient(Protocol):
    model: str

    def generate(self, prompt: str, context: Any | None = None) -> LLMResponse:
        ...


class OllamaClient:
    def __init__(
        self,
        model: str = "qwen:7b",
        base_url: str = "http://127.0.0.1:11434",
        timeout: int = 180,
        temperature: float = 0.0,
    ):
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.temperature = temperature

    def generate(self, prompt: str, context: Any | None = None) -> LLMResponse:
        started = time.perf_counter()
        try:
            body = json.dumps(
                {
                    "model": self.model,
                    "messages": [{"role": "user", "content": prompt}],
                    "stream": False,
                    "options": {"temperature": self.temperature, "seed": 42},
                }
            ).encode("utf-8")
            request = urllib.request.Request(
                f"{self.base_url}/api/chat",
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                payload = json.loads(response.read().decode("utf-8"))
            text = payload["message"]["content"]
        except (urllib.error.URLError, TimeoutError, KeyError, ValueError, json.JSONDecodeError) as exc:
            raise RuntimeError(
                f"Could not obtain a response from Ollama at {self.base_url} using {self.model}: {exc}"
            ) from exc
        latency = (time.perf_counter() - started) * 1000
        return LLMResponse(text=text.strip(), model=self.model, latency_ms=latency)


class OracleClient:
    """Ground-truth client used only to verify the experiment pipeline."""

    model = "oracle-pipeline-check"

    def generate(self, prompt: str, context: Any | None = None) -> LLMResponse:
        started = time.perf_counter()
        if isinstance(context, DirectionScenario):
            text = context.expected.value
        elif isinstance(context, RouteScenario):
            text = json.dumps([point.as_list() for point in context.optimal_path])
        elif isinstance(context, MissionScenario):
            text = json.dumps(
                {
                    "action": "pick_and_deliver",
                    "item_id": context.item_id,
                    "destination_id": context.destination_id,
                    "route": [point.as_list() for point in context.optimal_path],
                },
                separators=(",", ":"),
            )
        else:
            raise ValueError("OracleClient requires a scenario context")
        return LLMResponse(text=text, model=self.model, latency_ms=(time.perf_counter() - started) * 1000)


class RandomBaselineClient:
    """Weak reproducible baseline; it is not an LLM."""

    model = "random-baseline"

    def __init__(self, seed: int = 42):
        self.rng = random.Random(seed)

    def generate(self, prompt: str, context: Any | None = None) -> LLMResponse:
        started = time.perf_counter()
        if isinstance(context, DirectionScenario):
            text = self.rng.choice(tuple(Direction)).value
        elif isinstance(context, MissionScenario):
            text = "{}"
        else:
            text = "[]"
        return LLMResponse(text=text, model=self.model, latency_ms=(time.perf_counter() - started) * 1000)
