from __future__ import annotations

from dataclasses import dataclass, field

from .domain import Point


@dataclass
class WarehouseMap:
    width: int = 10
    height: int = 10
    objects: dict[Point, str] = field(default_factory=dict)
    traversable_labels: tuple[str, ...] = ("Dock",)

    def in_bounds(self, point: Point) -> bool:
        return 0 <= point.x < self.width and 0 <= point.y < self.height

    def is_blocked(self, point: Point) -> bool:
        label = self.objects.get(point)
        if label is None:
            return False
        return not any(label.startswith(prefix) for prefix in self.traversable_labels)

    def is_free(self, point: Point) -> bool:
        return self.in_bounds(point) and not self.is_blocked(point)

    def free_points(self) -> list[Point]:
        return [
            Point(x, y)
            for y in range(self.height)
            for x in range(self.width)
            if self.is_free(Point(x, y))
        ]

    def blocked_points(self) -> set[Point]:
        return {point for point in self.objects if self.is_blocked(point)}

    def object_lines(self) -> str:
        ordered = sorted(self.objects.items(), key=lambda item: (item[0].y, item[0].x))
        return "\n".join(f"- ({p.x},{p.y}): {label}" for p, label in ordered)

    def neighbors4(self, point: Point) -> list[Point]:
        candidates = (
            Point(point.x, point.y - 1),
            Point(point.x + 1, point.y),
            Point(point.x, point.y + 1),
            Point(point.x - 1, point.y),
        )
        return [candidate for candidate in candidates if self.is_free(candidate)]

    def pallet_objects(self) -> list[tuple[Point, str]]:
        return sorted(
            ((point, label) for point, label in self.objects.items() if label.startswith("Pallet")),
            key=lambda item: item[1],
        )

    def dock_objects(self) -> list[tuple[Point, str]]:
        return sorted(
            ((point, label) for point, label in self.objects.items() if label.startswith("Dock")),
            key=lambda item: item[1],
        )

    def access_points(self, object_point: Point) -> list[Point]:
        """Return free orthogonal cells from which a robot can access an object."""
        candidates = (
            Point(object_point.x, object_point.y - 1),
            Point(object_point.x + 1, object_point.y),
            Point(object_point.x, object_point.y + 1),
            Point(object_point.x - 1, object_point.y),
        )
        return [candidate for candidate in candidates if self.is_free(candidate)]


def object_identifier(label: str) -> str:
    """Extract identifiers such as P-5 or D-3 from warehouse labels."""
    parts = label.split()
    if len(parts) < 2:
        raise ValueError(f"Warehouse label has no identifier: {label}")
    return parts[1]


def default_warehouse() -> WarehouseMap:
    # Layout transcribed from the professor's supplied Qwen simulator notebook.
    raw: dict[tuple[int, int], str] = {
        (0, 0): "Worker W-6", (0, 3): "Pallet P-14 (Salt)",
        (0, 6): "Worker W-8", (0, 8): "Pallet P-9 (Cereal)",
        (1, 0): "Dock D-1", (1, 3): "Rack R-2 (Widgets)",
        (1, 4): "Rack R-2 (Widgets)", (1, 5): "Column C-5",
        (1, 7): "Rack R-1 (Motors)", (1, 8): "Rack R-1 (Motors)",
        (1, 9): "Forklift F-1", (2, 0): "Dock D-2",
        (2, 3): "Rack R-2 (Widgets)", (2, 4): "Rack R-2 (Widgets)",
        (2, 5): "Column C-1", (2, 7): "Rack R-1 (Motors)",
        (2, 8): "Rack R-1 (Motors)", (2, 9): "Pallet P-1 (Cola)",
        (3, 0): "Column C-2", (3, 2): "Pallet P-5 (Coffee)",
        (3, 4): "Pallet P-8 (Biscuits)", (3, 5): "Column C-3",
        (3, 7): "Pallet P-2 (Orange Juice)", (3, 8): "Pallet P-12 (Sugar)",
        (4, 0): "Dock D-3", (4, 2): "Rack R-6 (Bearings)",
        (4, 3): "Rack R-6 (Bearings)", (4, 4): "Rack R-6 (Bearings)",
        (4, 7): "Rack R-3 (Gaskets)", (4, 8): "Rack R-3 (Gaskets)",
        (4, 9): "Pallet P-4 (Tea)", (5, 2): "Rack R-6 (Bearings)",
        (5, 3): "Rack R-6 (Bearings)", (5, 4): "Rack R-6 (Bearings)",
        (5, 5): "Pallet P-15 (Cooking Oil)", (5, 7): "Rack R-3 (Gaskets)",
        (5, 8): "Rack R-3 (Gaskets)", (6, 0): "Dock D-4",
        (6, 3): "Pallet P-11 (Pasta)", (6, 4): "Pallet P-3 (Water)",
        (6, 7): "Pallet P-13 (Flour)", (6, 8): "Column C-4",
        (6, 9): "Forklift F-4", (7, 0): "Dock D-5",
        (7, 3): "Rack R-4 (Batteries)", (7, 4): "Rack R-4 (Batteries)",
        (7, 6): "Rack R-5 (Cables)", (7, 7): "Rack R-5 (Cables)",
        (7, 8): "Worker W-1", (7, 9): "Worker W-7",
        (8, 1): "Worker W-2", (8, 2): "Worker W-4",
        (8, 3): "Rack R-4 (Batteries)", (8, 4): "Rack R-4 (Batteries)",
        (8, 5): "Pallet P-6 (Milk)", (8, 6): "Rack R-5 (Cables)",
        (8, 7): "Rack R-5 (Cables)", (9, 1): "Worker W-5",
        (9, 3): "Pallet P-7 (Bread)", (9, 4): "Pallet P-10 (Rice)",
        (9, 5): "Worker W-3", (9, 7): "Pallet P-16 (Tomato Sauce)",
        (9, 8): "Forklift F-2", (9, 9): "Forklift F-3",
    }
    return WarehouseMap(objects={Point(x, y): label for (x, y), label in raw.items()})
