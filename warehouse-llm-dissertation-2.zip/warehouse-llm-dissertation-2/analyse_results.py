from __future__ import annotations

import argparse
import math
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


DIFFICULTY_ORDER = ["easy", "medium", "hard", "expert"]


def _as_bool(series: pd.Series) -> pd.Series:
    if series.dtype == bool:
        return series
    return series.astype(str).str.strip().str.casefold().eq("true")


def markdown_table(frame: pd.DataFrame) -> str:
    columns = [str(column) for column in frame.columns]
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join("---" for _ in columns) + " |",
    ]
    for values in frame.itertuples(index=False, name=None):
        lines.append("| " + " | ".join(str(value) for value in values) + " |")
    return "\n".join(lines)


def wilson_interval(successes: int, total: int, z: float = 1.96) -> tuple[float, float]:
    if total == 0:
        return float("nan"), float("nan")
    proportion = successes / total
    denominator = 1 + (z**2 / total)
    centre = (proportion + z**2 / (2 * total)) / denominator
    margin = (
        z
        * math.sqrt(proportion * (1 - proportion) / total + z**2 / (4 * total**2))
        / denominator
    )
    return max(0.0, centre - margin), min(1.0, centre + margin)


def aggregate(frame: pd.DataFrame, success_column: str) -> pd.DataFrame:
    rows = []
    for keys, group in frame.groupby(["model", "difficulty", "prompt_style"], dropna=False):
        successes = int(_as_bool(group[success_column]).sum())
        total = len(group)
        low, high = wilson_interval(successes, total)
        rows.append(
            {
                "model": keys[0],
                "difficulty": keys[1],
                "prompt_style": keys[2],
                "successes": successes,
                "n": total,
                "rate": successes / total,
                "ci95_low": low,
                "ci95_high": high,
            }
        )
    return pd.DataFrame(rows)


def plot_success(summary: pd.DataFrame, title: str, output: Path) -> None:
    fig, ax = plt.subplots(figsize=(10, 5.8))
    x_lookup = {name: index for index, name in enumerate(DIFFICULTY_ORDER)}
    for (model, style), group in summary.groupby(["model", "prompt_style"]):
        ordered = group.copy()
        ordered["x"] = ordered["difficulty"].map(x_lookup)
        ordered = ordered.sort_values("x")
        yerr = [
            ordered["rate"] - ordered["ci95_low"],
            ordered["ci95_high"] - ordered["rate"],
        ]
        ax.errorbar(
            ordered["x"], ordered["rate"], yerr=yerr, marker="o", capsize=3,
            label=f"{model} — {style}",
        )
    ax.set_xticks(range(len(DIFFICULTY_ORDER)), [name.title() for name in DIFFICULTY_ORDER])
    ax.set_ylim(0, 1.03)
    ax.set_ylabel("Success proportion (95% Wilson CI)")
    ax.set_xlabel("Difficulty")
    ax.set_title(title)
    ax.grid(axis="y", alpha=0.25)
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(output, dpi=220, bbox_inches="tight")
    plt.close(fig)


def main() -> int:
    parser = argparse.ArgumentParser(description="Analyse Warehouse LLM experiment CSV files")
    parser.add_argument("--input-dir", default="results/final")
    parser.add_argument("--output-dir", default="results/analysis")
    args = parser.parse_args()
    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_files = sorted(input_dir.glob("*.csv"))
    if not csv_files:
        raise SystemExit(f"No CSV files found in {input_dir}")
    frames = [pd.read_csv(path) for path in csv_files]
    combined = pd.concat(frames, ignore_index=True, sort=False)
    report_lines = ["# Experimental results", ""]

    direction = combined[combined["task"] == "direction"].copy()
    if not direction.empty:
        summary = aggregate(direction, "correct")
        summary.to_csv(output_dir / "direction_summary_with_ci.csv", index=False)
        plot_success(summary, "LLM direction accuracy", output_dir / "direction_accuracy.png")
        report_lines.extend(["## Direction reasoning", "", markdown_table(summary), ""])
        confusion = pd.crosstab(
            direction["expected"], direction["parsed_response"], dropna=False, margins=True
        )
        confusion.to_csv(output_dir / "direction_confusion_matrix.csv")

    route = combined[combined["task"] == "route"].copy()
    if not route.empty:
        summary = aggregate(route, "valid_route")
        summary.to_csv(output_dir / "route_summary_with_ci.csv", index=False)
        plot_success(summary, "LLM valid-route rate", output_dir / "valid_route_rate.png")
        report_lines.extend(["## Route planning", "", markdown_table(summary), ""])
        failure_columns = [
            "parseable", "starts_correctly", "reaches_goal", "moves_are_adjacent", "collision_free"
        ]
        failure_rows = []
        for column in failure_columns:
            failure_rows.append(
                {"criterion": column, "failure_count": int((~_as_bool(route[column])).sum())}
            )
        pd.DataFrame(failure_rows).to_csv(output_dir / "route_failure_counts.csv", index=False)

    mission = combined[combined["task"] == "mission"].copy()
    if not mission.empty:
        summary = aggregate(mission, "valid_mission")
        summary.to_csv(output_dir / "mission_summary_with_ci.csv", index=False)
        plot_success(summary, "Valid pick-and-deliver mission rate", output_dir / "valid_mission_rate.png")
        report_lines.extend(["## Pick-and-deliver task planning", "", markdown_table(summary), ""])
        failure_columns = [
            "format_compliant",
            "action_correct",
            "item_correct",
            "destination_correct",
            "parseable_route",
            "starts_correctly",
            "reaches_destination",
            "moves_are_adjacent",
            "collision_free",
            "pickup_visited",
        ]
        failure_rows = []
        for column in failure_columns:
            failure_rows.append(
                {"criterion": column, "failure_count": int((~_as_bool(mission[column])).sum())}
            )
        pd.DataFrame(failure_rows).to_csv(output_dir / "mission_failure_counts.csv", index=False)

    (output_dir / "results_summary.md").write_text("\n".join(report_lines), encoding="utf-8")
    print(f"Analysis saved in {output_dir.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
