# Accuracy and automatic report guide

## What to run

After all three final CSV files have been created, run Section 7 of
`Warehouse_LLM_Experiments_Mac.ipynb`. The notebook calls:

```bash
python analyse_results.py --input-dir results/final --output-dir results/analysis
```

The calculation is automatic. Do not type percentages manually and do not remove
incorrect, malformed or timed-out responses.

## Which number is the accuracy?

The project has three different primary outcomes because the tasks are not identical.

| Task | Primary outcome | Meaning |
|---|---|---|
| Direction reasoning | `correct` | Parsed compass direction equals the simulator ground truth |
| Route planning | `valid_route` | Route starts correctly, uses adjacent legal moves, avoids obstacles and reaches the goal |
| Pick-and-deliver mission | `valid_mission` | Item and destination are correct and the complete route legally visits pickup access before the dock |

Always report each task separately as `successes / total (percentage, 95% CI)`.
The software also prints a case-weighted combined success rate, but this is descriptive
only. It must not replace the three primary results because the success definitions differ
and direction reasoning has twice as many cases.

## Files produced in `results/analysis`

| File | Use |
|---|---|
| `experiment_integrity.csv` | Confirms expected case counts, conditions, unique scenario IDs and inference-error counts |
| `overall_accuracy_summary.csv` | Main primary and diagnostic results with numerators, denominators and Wilson intervals |
| `condition_accuracy_summary.csv` | Primary result for every difficulty × prompt-style condition |
| `primary_accuracy_by_difficulty.csv` | Main result averaged within each difficulty |
| `primary_accuracy_by_prompt_style.csv` | Main result averaged within each prompt style |
| `accuracy_overview.png` | Dissertation-ready overview of the three primary outcomes |
| `direction_accuracy.png` | Direction result by difficulty and prompt style |
| `valid_route_rate.png` | Valid-route result by difficulty and prompt style |
| `valid_mission_rate.png` | Valid-mission result by difficulty and prompt style |
| `direction_confusion_matrix.csv` | Expected directions compared with parsed answers |
| `route_failure_counts.csv` | Counts of route validation criteria that failed |
| `mission_failure_counts.csv` | Counts of task, pickup and navigation criteria that failed |
| `brief_accuracy_report.md` | Automatically written short results report |
| `results_summary.md` | Detailed condition table for all three experiments |

## Accuracy formula

For any binary outcome:

```text
accuracy = number of successful cases / total number of cases
percentage = accuracy × 100
```

For example, 38 successful direction cases out of 480 gives:

```text
38 / 480 = 0.0791667 = 7.92%
```

The analysis code uses a 95% Wilson confidence interval because it behaves better than
the simple normal approximation when a rate is near 0% or 100%.

## Integrity status

- `PASS`: expected sample size and conditions are complete, scenario IDs are unique and
  there are no recorded inference errors.
- `PASS_WITH_RECORDED_INFERENCE_ERRORS`: the design is complete; model/server errors are
  recorded and correctly remain failures in the denominator.
- `CHECK_DESIGN`: a file is missing cases, contains duplicated scenario IDs, or does not
  match the planned conditions. Resolve and document this before reporting final accuracy.

The analysis deliberately stops when duplicate scenario IDs are found. Silent
deduplication could hide selective reruns and would weaken the dissertation evidence.

## Safe wording for the report

Use language such as:

> Qwen 7B achieved X/Y (Z%, 95% Wilson CI L%–U%) on the primary outcome.

For differences between prompt styles or difficulty levels, write “the highest observed
rate” or “a descriptive difference”. Do not call a difference statistically significant
from the graph alone. Formal inference should be agreed with the supervisor; binary
logistic regression is a possible next analysis when the data contain enough successes.

Low or zero end-to-end validity is a legitimate result. Discuss the diagnostic measures
to show whether failure arose from formatting, task interpretation, reaching the goal,
non-adjacent moves, collisions or missed pickup access.
