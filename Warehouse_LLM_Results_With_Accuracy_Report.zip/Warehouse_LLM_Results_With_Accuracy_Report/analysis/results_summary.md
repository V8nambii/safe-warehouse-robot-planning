# Detailed experimental results

## Direction reasoning

| task | model | difficulty | prompt_style | successes | n | rate | rate_percent | ci95_low | ci95_high |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| direction | qwen:7b | easy | distractor_map | 9 | 30 | 0.3 | 30.0 | 0.16664562643958933 | 0.4787612101166018 |
| direction | qwen:7b | easy | few_shot | 6 | 30 | 0.2 | 20.0 | 0.09504978102401235 | 0.37306047381027446 |
| direction | qwen:7b | easy | minimal | 0 | 30 | 0.0 | 0.0 | 0.0 | 0.113517091390478 |
| direction | qwen:7b | easy | rules | 0 | 30 | 0.0 | 0.0 | 0.0 | 0.113517091390478 |
| direction | qwen:7b | expert | distractor_map | 4 | 30 | 0.13333333333333333 | 13.33 | 0.05309569424218104 | 0.2968168394441695 |
| direction | qwen:7b | expert | few_shot | 4 | 30 | 0.13333333333333333 | 13.33 | 0.05309569424218104 | 0.2968168394441695 |
| direction | qwen:7b | expert | minimal | 2 | 30 | 0.06666666666666667 | 6.67 | 0.01847663532769335 | 0.21323817721072091 |
| direction | qwen:7b | expert | rules | 0 | 30 | 0.0 | 0.0 | 0.0 | 0.113517091390478 |
| direction | qwen:7b | hard | distractor_map | 1 | 30 | 0.03333333333333333 | 3.33 | 0.0059084379948573795 | 0.16670751396958874 |
| direction | qwen:7b | hard | few_shot | 3 | 30 | 0.1 | 10.0 | 0.03459925995971615 | 0.25621441315266624 |
| direction | qwen:7b | hard | minimal | 3 | 30 | 0.1 | 10.0 | 0.03459925995971615 | 0.25621441315266624 |
| direction | qwen:7b | hard | rules | 0 | 30 | 0.0 | 0.0 | 0.0 | 0.113517091390478 |
| direction | qwen:7b | medium | distractor_map | 2 | 30 | 0.06666666666666667 | 6.67 | 0.01847663532769335 | 0.21323817721072091 |
| direction | qwen:7b | medium | few_shot | 3 | 30 | 0.1 | 10.0 | 0.03459925995971615 | 0.25621441315266624 |
| direction | qwen:7b | medium | minimal | 1 | 30 | 0.03333333333333333 | 3.33 | 0.0059084379948573795 | 0.16670751396958874 |
| direction | qwen:7b | medium | rules | 0 | 30 | 0.0 | 0.0 | 0.0 | 0.113517091390478 |

## Route planning

| task | model | difficulty | prompt_style | successes | n | rate | rate_percent | ci95_low | ci95_high |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| route | qwen:7b | easy | few_shot | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| route | qwen:7b | easy | minimal | 1 | 20 | 0.05 | 5.0 | 0.008881219432873136 | 0.23613589351256675 |
| route | qwen:7b | easy | rules | 1 | 20 | 0.05 | 5.0 | 0.008881219432873136 | 0.23613589351256675 |
| route | qwen:7b | expert | few_shot | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| route | qwen:7b | expert | minimal | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| route | qwen:7b | expert | rules | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| route | qwen:7b | hard | few_shot | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| route | qwen:7b | hard | minimal | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| route | qwen:7b | hard | rules | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| route | qwen:7b | medium | few_shot | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| route | qwen:7b | medium | minimal | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| route | qwen:7b | medium | rules | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |

## Pick-and-deliver task planning

| task | model | difficulty | prompt_style | successes | n | rate | rate_percent | ci95_low | ci95_high |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| mission | qwen:7b | easy | few_shot | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| mission | qwen:7b | easy | minimal | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| mission | qwen:7b | easy | rules | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| mission | qwen:7b | expert | few_shot | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| mission | qwen:7b | expert | minimal | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| mission | qwen:7b | expert | rules | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| mission | qwen:7b | hard | few_shot | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| mission | qwen:7b | hard | minimal | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| mission | qwen:7b | hard | rules | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| mission | qwen:7b | medium | few_shot | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| mission | qwen:7b | medium | minimal | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
| mission | qwen:7b | medium | rules | 0 | 20 | 0.0 | 0.0 | 0.0 | 0.16113012549493322 |
