# Brief accuracy report

## Method

This report was generated directly from the final CSV files. Each binary outcome is reported as successes/total, a percentage, and a two-sided 95% Wilson confidence interval. Failed, malformed and timed-out model responses remain in the denominator.

## Data-integrity checks

| task | expected_cases | observed_cases | unique_scenarios | duplicate_scenario_rows | expected_conditions | observed_conditions | cases_per_condition_min | cases_per_condition_max | inference_errors | status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| direction | 480 | 480 | 480 | 0 | 16 | 16 | 30 | 30 | 0 | PASS |
| route | 240 | 240 | 240 | 0 | 12 | 12 | 20 | 20 | 0 | PASS |
| mission | 240 | 240 | 240 | 0 | 12 | 12 | 20 | 20 | 0 | PASS |

## Primary results

| Task | Metric | Result | 95% Wilson CI |
| --- | --- | --- | --- |
| Direction reasoning | Direction accuracy | 38/480 (7.92%) | 5.82%–10.68% |
| Route planning | Valid-route rate | 2/240 (0.83%) | 0.23%–2.99% |
| Pick-and-deliver mission | Valid-mission rate | 0/240 (0.00%) | 0.00%–1.58% |

- **Direction reasoning:** 38 of 480 cases succeeded (7.92%, 95% CI 5.82%–10.68%).
- **Route planning:** 2 of 240 cases succeeded (0.83%, 95% CI 0.23%–2.99%).
- **Pick-and-deliver mission:** 0 of 240 cases succeeded (0.00%, 95% CI 0.00%–1.58%).

Across all heterogeneous tasks, the case-weighted primary success count was 40/960 (4.17%). This is a descriptive combined rate, not a single interchangeable definition of accuracy, because the three tasks use different success criteria and the direction task has twice as many cases.

## Diagnostic results

| Task | Metric | Result | 95% Wilson CI |
| --- | --- | --- | --- |
| Direction reasoning | Strict direction accuracy | 25/480 (5.21%) | 3.55%–7.58% |
| Direction reasoning | One-label format compliance | 210/480 (43.75%) | 39.38%–48.22% |
| Route planning | Optimal-route rate | 2/240 (0.83%) | 0.23%–2.99% |
| Route planning | Parseable route rate | 184/240 (76.67%) | 70.92%–81.57% |
| Route planning | Correct-start rate | 184/240 (76.67%) | 70.92%–81.57% |
| Route planning | Goal-reaching rate | 25/240 (10.42%) | 7.16%–14.92% |
| Route planning | Adjacent-move rate | 4/240 (1.67%) | 0.65%–4.21% |
| Route planning | Collision-free rate | 11/240 (4.58%) | 2.58%–8.02% |
| Pick-and-deliver mission | Semantic task accuracy | 11/240 (4.58%) | 2.58%–8.02% |
| Pick-and-deliver mission | Optimal-mission rate | 0/240 (0.00%) | 0.00%–1.58% |
| Pick-and-deliver mission | JSON/schema compliance | 9/240 (3.75%) | 1.99%–6.97% |
| Pick-and-deliver mission | Pickup-visit rate | 4/240 (1.67%) | 0.65%–4.21% |
| Pick-and-deliver mission | Parseable route rate | 11/240 (4.58%) | 2.58%–8.02% |
| Pick-and-deliver mission | Correct-start rate | 11/240 (4.58%) | 2.58%–8.02% |
| Pick-and-deliver mission | Destination-reaching rate | 1/240 (0.42%) | 0.07%–2.32% |
| Pick-and-deliver mission | Adjacent-move rate | 4/240 (1.67%) | 0.65%–4.21% |
| Pick-and-deliver mission | Collision-free rate | 0/240 (0.00%) | 0.00%–1.58% |

## Condition-level observations

- **Direction reasoning:** the highest observed condition was easy difficulty with the distractor_map prompt (9/30, 30.00%).
- **Route planning:** 2 conditions tied for the highest observed rate of 5.00%: easy/minimal (1/20); easy/rules (1/20).
- **Pick-and-deliver mission:** all 12 conditions tied at the highest observed rate of 0.00%.

These condition comparisons are descriptive. Small condition samples and overlapping confidence intervals mean that a visual difference alone should not be described as statistically significant.

## Interpretation for the dissertation

The experiment measures spatial reasoning and constrained planning, not physical robot performance. A valid route must be parseable, start correctly, use adjacent legal moves, avoid obstacles and reach the goal. A valid mission must also select the requested item and destination and visit a legal pickup-access cell. The strict end-to-end definitions explain why route and mission scores can be much lower than JSON parseability or semantic task accuracy. Low scores are legitimate findings and must not be removed or manually fixed.

## Reproducibility note

Retain the raw final CSV files, executed notebook, model name and digest, temperature, scenario seeds, Python/Ollama versions and Mac hardware details. The oracle check validates the software pipeline and must not be reported as LLM accuracy.
