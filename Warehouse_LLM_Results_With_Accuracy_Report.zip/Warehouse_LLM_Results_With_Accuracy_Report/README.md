# Results directory

Generated experiment files belong here but are intentionally not included as final evidence.

Suggested separation:

- `oracle_check/` — software-pipeline verification only
- `pilot/` — small model pilot, excluded from final analysis
- `final/` — unedited final Qwen CSV and JSON files
- `analysis/` — derived tables, confidence intervals and figures

Never copy oracle results into `final/`. Genuine final results must be produced by running the approved LLM experiment.

The final folder should normally contain separate `direction_*.csv`, `route_*.csv` and `mission_*.csv` files.
